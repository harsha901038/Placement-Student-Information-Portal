export type UserRole = "student" | "admin"

export interface User {
  id: string
  email: string
  name: string
  role: UserRole
  avatar?: string
}

export interface Student {
  id: string
  userId: string
  name: string
  email: string
  phone: string
  department: string
  semester: number
  rollNumber: string
  cgpa: number
  attendance: number
  skills: string[]
  placementStatus: "not-applied" | "applied" | "shortlisted" | "placed"
  companyPlaced?: string
  resumeScore?: number
  resumeCompleted: number
  lastResumeUpdate?: string
  certificates: Certificate[]
  marks: SemesterMarks[]
  appliedJobs: string[]
}

export interface Certificate {
  id: string
  name: string
  issuer: string
  date: string
  verified: boolean
  fileUrl?: string
}

export interface SemesterMarks {
  semester: number
  subjects: {
    name: string
    marks: number
    maxMarks: number
  }[]
  sgpa: number
}

export interface Resume {
  id: string
  studentId: string
  personalInfo: {
    name: string
    email: string
    phone: string
    address: string
    linkedin?: string
    github?: string
    portfolio?: string
  }
  objective: string
  education: {
    degree: string
    institution: string
    year: string
    grade: string
  }[]
  skills: string[]
  experience: {
    title: string
    company: string
    duration: string
    description: string
  }[]
  projects: {
    name: string
    description: string
    technologies: string[]
    link?: string
  }[]
  certifications: string[]
  achievements: string[]
}

export interface Job {
  id: string
  title: string
  company: string
  logo?: string
  location: string
  type: "full-time" | "part-time" | "internship"
  salary: string
  description: string
  requirements: string[]
  skills: string[]
  postedDate: string
  deadline: string
  applicants: number
  status: "open" | "closed"
}

export interface Announcement {
  id: string
  title: string
  content: string
  date: string
  priority: "low" | "medium" | "high"
  author: string
}

export interface AnalyticsData {
  totalStudents: number
  placedStudents: number
  averageCGPA: number
  averageAttendance: number
  resumeCompletionRate: number
  departmentWisePlacement: {
    department: string
    total: number
    placed: number
  }[]
  monthlyPlacements: {
    month: string
    count: number
  }[]
}
