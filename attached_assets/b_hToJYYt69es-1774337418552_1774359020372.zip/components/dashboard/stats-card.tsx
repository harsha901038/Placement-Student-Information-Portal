import { Card, CardContent } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import type { LucideIcon } from "lucide-react"

interface StatsCardProps {
  title: string
  value: string | number
  subtitle?: string
  icon: LucideIcon
  trend?: {
    value: number
    isPositive: boolean
  }
  variant?: "default" | "primary" | "accent" | "warning"
}

const variantStyles = {
  default: {
    icon: "bg-muted text-muted-foreground",
    trend: "text-accent",
  },
  primary: {
    icon: "bg-primary/20 text-primary",
    trend: "text-primary",
  },
  accent: {
    icon: "bg-accent/20 text-accent",
    trend: "text-accent",
  },
  warning: {
    icon: "bg-warning/20 text-warning",
    trend: "text-warning",
  },
}

export function StatsCard({ title, value, subtitle, icon: Icon, trend, variant = "default" }: StatsCardProps) {
  const styles = variantStyles[variant]

  return (
    <Card className="border-border bg-card">
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div className="space-y-2">
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <p className="text-2xl font-bold text-foreground">{value}</p>
            {subtitle && <p className="text-xs text-muted-foreground">{subtitle}</p>}
            {trend && (
              <p className={cn("text-sm font-medium", trend.isPositive ? "text-accent" : "text-destructive")}>
                {trend.isPositive ? "+" : "-"}{Math.abs(trend.value)}%
                <span className="ml-1 text-muted-foreground">from last month</span>
              </p>
            )}
          </div>
          <div className={cn("flex h-12 w-12 items-center justify-center rounded-lg", styles.icon)}>
            <Icon className="h-6 w-6" />
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
