"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Spinner } from "@/components/ui/spinner"
import { GraduationCap, Briefcase, ArrowRight, User, Lock } from "lucide-react"

export default function LoginPage() {
  const router = useRouter()
  const { login, isAuthenticated, user, isLoading: authLoading } = useAuth()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  useEffect(() => {
    if (isAuthenticated && user) {
      router.push(user.role === "admin" ? "/admin" : "/dashboard")
    }
  }, [isAuthenticated, user, router])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    const result = await login(email, password)

    if (!result.success) {
      setError(result.error || "Login failed")
      setIsLoading(false)
    }
  }

  const handleDemoLogin = async (role: "student" | "admin") => {
    setError("")
    setIsLoading(true)
    const demoEmail = role === "admin" ? "admin@college.edu" : "john.student@college.edu"
    const result = await login(demoEmail, "demo")

    if (!result.success) {
      setError(result.error || "Login failed")
      setIsLoading(false)
    }
  }

  if (authLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Spinner className="h-8 w-8 text-primary" />
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col lg:flex-row">
      {/* Left Panel - Branding */}
      <div className="relative flex flex-1 flex-col justify-between bg-background p-8 lg:p-12">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -left-1/4 -top-1/4 h-[600px] w-[600px] rounded-full bg-primary/10 blur-3xl" />
          <div className="absolute -bottom-1/4 -right-1/4 h-[400px] w-[400px] rounded-full bg-accent/10 blur-3xl" />
        </div>

        <div className="relative">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
              <GraduationCap className="h-6 w-6 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-foreground">Student Portal</span>
          </div>
        </div>

        <div className="relative space-y-6">
          <h1 className="text-balance text-4xl font-bold tracking-tight text-foreground lg:text-5xl">
            Your Career Journey
            <br />
            <span className="text-primary">Starts Here</span>
          </h1>
          <p className="max-w-md text-lg text-muted-foreground">
            AI-powered placement portal that helps students build careers and empowers institutions to manage placements efficiently.
          </p>

          <div className="flex flex-col gap-4 sm:flex-row">
            <div className="flex items-center gap-3 rounded-lg border border-border bg-card/50 p-4 backdrop-blur-sm">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/20">
                <GraduationCap className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="font-medium text-foreground">For Students</p>
                <p className="text-sm text-muted-foreground">Build resumes & track placements</p>
              </div>
            </div>
            <div className="flex items-center gap-3 rounded-lg border border-border bg-card/50 p-4 backdrop-blur-sm">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/20">
                <Briefcase className="h-5 w-5 text-accent" />
              </div>
              <div>
                <p className="font-medium text-foreground">For Admins</p>
                <p className="text-sm text-muted-foreground">Manage & analyze placements</p>
              </div>
            </div>
          </div>
        </div>

        <div className="relative text-sm text-muted-foreground">
          &copy; 2024 Student Portal. Built for modern institutions.
        </div>
      </div>

      {/* Right Panel - Login Form */}
      <div className="flex flex-1 items-center justify-center bg-card p-8 lg:p-12">
        <div className="w-full max-w-md space-y-8">
          <div className="space-y-2 text-center">
            <h2 className="text-2xl font-bold text-foreground">Welcome back</h2>
            <p className="text-muted-foreground">Sign in to access your dashboard</p>
          </div>

          <Card className="border-border bg-secondary/30">
            <CardHeader className="space-y-1 pb-4">
              <CardTitle className="text-lg">Sign In</CardTitle>
              <CardDescription>Enter your credentials to continue</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      type="email"
                      placeholder="Email address"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      type="password"
                      placeholder="Password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>

                {error && (
                  <p className="text-sm text-destructive">{error}</p>
                )}

                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? (
                    <Spinner className="h-4 w-4" />
                  ) : (
                    <>
                      Sign In
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </>
                  )}
                </Button>
              </form>

              <div className="relative my-6">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-border" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-card px-2 text-muted-foreground">Or try demo</span>
                </div>
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => handleDemoLogin("student")}
                  disabled={isLoading}
                  className="w-full"
                >
                  <GraduationCap className="mr-2 h-4 w-4" />
                  Student Demo
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => handleDemoLogin("admin")}
                  disabled={isLoading}
                  className="w-full"
                >
                  <Briefcase className="mr-2 h-4 w-4" />
                  Admin Demo
                </Button>
              </div>
            </CardContent>
          </Card>

          <p className="text-center text-sm text-muted-foreground">
            Demo credentials: Use any password with the demo accounts
          </p>
        </div>
      </div>
    </div>
  )
}
