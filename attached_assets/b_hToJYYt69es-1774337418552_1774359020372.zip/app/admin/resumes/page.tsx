"use client"

import { useState } from "react"
import { DashboardHeader } from "@/components/dashboard/header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { students } from "@/lib/data"
import {
  Search,
  Filter,
  FileText,
  CheckCircle,
  XCircle,
  Eye,
  Download,
  ThumbsUp,
  ThumbsDown,
} from "lucide-react"

export default function ResumesPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [scoreFilter, setScoreFilter] = useState<string>("all")
  const [completionFilter, setCompletionFilter] = useState<string>("all")
  const [resumeStatuses, setResumeStatuses] = useState<Record<string, "approved" | "rejected" | "pending">>({})

  const filteredStudents = students.filter((student) => {
    const matchesSearch =
      student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.skills.some((skill) => skill.toLowerCase().includes(searchQuery.toLowerCase()))
    
    const score = student.resumeScore || 0
    const matchesScore =
      scoreFilter === "all" ||
      (scoreFilter === "high" && score >= 80) ||
      (scoreFilter === "medium" && score >= 50 && score < 80) ||
      (scoreFilter === "low" && score < 50)
    
    const completion = student.resumeCompleted
    const matchesCompletion =
      completionFilter === "all" ||
      (completionFilter === "complete" && completion >= 80) ||
      (completionFilter === "partial" && completion >= 50 && completion < 80) ||
      (completionFilter === "incomplete" && completion < 50)

    return matchesSearch && matchesScore && matchesCompletion
  })

  const handleApprove = (studentId: string) => {
    setResumeStatuses({ ...resumeStatuses, [studentId]: "approved" })
  }

  const handleReject = (studentId: string) => {
    setResumeStatuses({ ...resumeStatuses, [studentId]: "rejected" })
  }

  const approvedCount = Object.values(resumeStatuses).filter((s) => s === "approved").length
  const rejectedCount = Object.values(resumeStatuses).filter((s) => s === "rejected").length
  const pendingCount = students.length - approvedCount - rejectedCount

  const getScoreBadge = (score: number) => {
    if (score >= 80) return { className: "bg-accent text-accent-foreground", label: "Excellent" }
    if (score >= 60) return { className: "bg-primary/20 text-primary", label: "Good" }
    if (score >= 40) return { className: "bg-warning/20 text-warning", label: "Average" }
    return { className: "bg-destructive/20 text-destructive", label: "Poor" }
  }

  return (
    <div className="flex flex-col">
      <DashboardHeader
        title="Resume Monitoring"
        description="Review and approve student resumes"
      />

      <div className="flex-1 space-y-6 p-6">
        {/* Stats */}
        <div className="grid gap-4 sm:grid-cols-4">
          <Card className="border-border bg-card">
            <CardContent className="flex items-center gap-4 p-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/20 text-primary">
                <FileText className="h-5 w-5" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{students.length}</p>
                <p className="text-xs text-muted-foreground">Total Resumes</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-border bg-card">
            <CardContent className="flex items-center gap-4 p-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/20 text-accent">
                <CheckCircle className="h-5 w-5" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{approvedCount}</p>
                <p className="text-xs text-muted-foreground">Approved</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-border bg-card">
            <CardContent className="flex items-center gap-4 p-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-destructive/20 text-destructive">
                <XCircle className="h-5 w-5" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{rejectedCount}</p>
                <p className="text-xs text-muted-foreground">Rejected</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-border bg-card">
            <CardContent className="flex items-center gap-4 p-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-warning/20 text-warning">
                <FileText className="h-5 w-5" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{pendingCount}</p>
                <p className="text-xs text-muted-foreground">Pending Review</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="border-border bg-card">
          <CardContent className="p-4">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search by name or skills..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <div className="flex gap-2">
                <Select value={scoreFilter} onValueChange={setScoreFilter}>
                  <SelectTrigger className="w-[150px]">
                    <Filter className="mr-2 h-4 w-4" />
                    <SelectValue placeholder="Score" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Scores</SelectItem>
                    <SelectItem value="high">High (80+)</SelectItem>
                    <SelectItem value="medium">Medium (50-79)</SelectItem>
                    <SelectItem value="low">Low (0-49)</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={completionFilter} onValueChange={setCompletionFilter}>
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="Completion" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="complete">Complete (80%+)</SelectItem>
                    <SelectItem value="partial">Partial (50-79%)</SelectItem>
                    <SelectItem value="incomplete">Incomplete (0-49%)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Resume Cards */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filteredStudents.map((student) => {
            const score = student.resumeScore || 0
            const scoreBadge = getScoreBadge(score)
            const status = resumeStatuses[student.id] || "pending"

            return (
              <Card key={student.id} className="border-border bg-card">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/20 text-primary">
                        <FileText className="h-6 w-6" />
                      </div>
                      <div>
                        <p className="font-medium text-foreground">{student.name}</p>
                        <p className="text-sm text-muted-foreground">{student.department}</p>
                      </div>
                    </div>
                    <Badge className={scoreBadge.className}>{score}/100</Badge>
                  </div>

                  <div className="mt-4 space-y-3">
                    <div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Completion</span>
                        <span className="font-medium text-foreground">{student.resumeCompleted}%</span>
                      </div>
                      <Progress value={student.resumeCompleted} className="mt-1 h-2" />
                    </div>

                    <div>
                      <p className="mb-2 text-sm text-muted-foreground">Skills</p>
                      <div className="flex flex-wrap gap-1">
                        {student.skills.slice(0, 4).map((skill) => (
                          <Badge key={skill} variant="outline" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                        {student.skills.length > 4 && (
                          <Badge variant="outline" className="text-xs">
                            +{student.skills.length - 4}
                          </Badge>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Last Updated</span>
                      <span className="text-foreground">{student.lastResumeUpdate || "N/A"}</span>
                    </div>
                  </div>

                  <div className="mt-4 flex items-center justify-between border-t border-border pt-4">
                    <Badge
                      variant="outline"
                      className={
                        status === "approved"
                          ? "border-accent text-accent"
                          : status === "rejected"
                          ? "border-destructive text-destructive"
                          : ""
                      }
                    >
                      {status.charAt(0).toUpperCase() + status.slice(1)}
                    </Badge>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleApprove(student.id)}
                        className={status === "approved" ? "bg-accent text-accent-foreground" : ""}
                      >
                        <ThumbsUp className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleReject(student.id)}
                        className={status === "rejected" ? "bg-destructive text-destructive-foreground" : ""}
                      >
                        <ThumbsDown className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>
    </div>
  )
}
