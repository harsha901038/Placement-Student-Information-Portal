"use client"

import { DashboardHeader } from "@/components/dashboard/header"
import { StatsCard } from "@/components/dashboard/stats-card"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { analyticsData, students, jobs } from "@/lib/data"
import {
  Users,
  Briefcase,
  GraduationCap,
  FileText,
  TrendingUp,
  Target,
  Calendar,
  Award,
  CheckCircle,
} from "lucide-react"
import {
  Bar,
  BarChart,
  Line,
  LineChart,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

const placementRate = ((analyticsData.placedStudents / analyticsData.totalStudents) * 100).toFixed(1)

// Prepare data for pie chart
const placementStatusData = [
  { name: "Placed", value: students.filter((s) => s.placementStatus === "placed").length },
  { name: "Shortlisted", value: students.filter((s) => s.placementStatus === "shortlisted").length },
  { name: "Applied", value: students.filter((s) => s.placementStatus === "applied").length },
  { name: "Not Applied", value: students.filter((s) => s.placementStatus === "not-applied").length },
]

const COLORS = ["var(--color-accent)", "var(--color-warning)", "var(--color-primary)", "var(--color-muted)"]

// Resume score distribution
const resumeScoreDistribution = [
  { range: "0-40", count: students.filter((s) => (s.resumeScore || 0) <= 40).length },
  { range: "41-60", count: students.filter((s) => (s.resumeScore || 0) > 40 && (s.resumeScore || 0) <= 60).length },
  { range: "61-80", count: students.filter((s) => (s.resumeScore || 0) > 60 && (s.resumeScore || 0) <= 80).length },
  { range: "81-100", count: students.filter((s) => (s.resumeScore || 0) > 80).length },
]

// CGPA distribution
const cgpaDistribution = [
  { range: "Below 6", count: students.filter((s) => s.cgpa < 6).length },
  { range: "6-7", count: students.filter((s) => s.cgpa >= 6 && s.cgpa < 7).length },
  { range: "7-8", count: students.filter((s) => s.cgpa >= 7 && s.cgpa < 8).length },
  { range: "8-9", count: students.filter((s) => s.cgpa >= 8 && s.cgpa < 9).length },
  { range: "9+", count: students.filter((s) => s.cgpa >= 9).length },
]

export default function AnalyticsPage() {
  return (
    <div className="flex flex-col">
      <DashboardHeader
        title="Analytics Dashboard"
        description="Comprehensive placement and student analytics"
      />

      <div className="flex-1 space-y-6 p-6">
        {/* Key Metrics */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatsCard
            title="Total Students"
            value={analyticsData.totalStudents}
            icon={Users}
            variant="primary"
            trend={{ value: 12, isPositive: true }}
          />
          <StatsCard
            title="Placement Rate"
            value={`${placementRate}%`}
            icon={TrendingUp}
            variant="accent"
            trend={{ value: 8, isPositive: true }}
          />
          <StatsCard
            title="Open Positions"
            value={jobs.filter((j) => j.status === "open").length}
            icon={Briefcase}
            variant="primary"
          />
          <StatsCard
            title="Avg. Resume Score"
            value={(students.reduce((sum, s) => sum + (s.resumeScore || 0), 0) / students.length).toFixed(0)}
            icon={FileText}
            variant="warning"
          />
        </div>

        {/* Charts Row 1 */}
        <div className="grid gap-6 lg:grid-cols-2">
          {/* Placement Status Distribution */}
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle>Placement Status Distribution</CardTitle>
              <CardDescription>Current status of all students</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center">
                <ChartContainer
                  config={{
                    placed: { label: "Placed", color: "var(--color-accent)" },
                    shortlisted: { label: "Shortlisted", color: "var(--color-warning)" },
                    applied: { label: "Applied", color: "var(--color-primary)" },
                    notApplied: { label: "Not Applied", color: "var(--color-muted)" },
                  }}
                  className="h-[300px] w-full"
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={placementStatusData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {placementStatusData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <ChartTooltip content={<ChartTooltipContent />} />
                    </PieChart>
                  </ResponsiveContainer>
                </ChartContainer>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-4">
                {placementStatusData.map((item, index) => (
                  <div key={item.name} className="flex items-center gap-2">
                    <div
                      className="h-3 w-3 rounded-full"
                      style={{ backgroundColor: COLORS[index] }}
                    />
                    <span className="text-sm text-muted-foreground">
                      {item.name}: {item.value}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Monthly Placements Trend */}
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle>Monthly Placement Trend</CardTitle>
              <CardDescription>Number of placements per month</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  count: { label: "Placements", color: "var(--color-primary)" },
                }}
                className="h-[300px]"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={analyticsData.monthlyPlacements}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                    <XAxis dataKey="month" stroke="var(--color-muted-foreground)" fontSize={12} />
                    <YAxis stroke="var(--color-muted-foreground)" fontSize={12} />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Line
                      type="monotone"
                      dataKey="count"
                      stroke="var(--color-primary)"
                      strokeWidth={2}
                      dot={{ fill: "var(--color-primary)", strokeWidth: 2 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>
        </div>

        {/* Charts Row 2 */}
        <div className="grid gap-6 lg:grid-cols-2">
          {/* Resume Score Distribution */}
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle>Resume Score Distribution</CardTitle>
              <CardDescription>Distribution of AI resume scores</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  count: { label: "Students", color: "var(--color-accent)" },
                }}
                className="h-[250px]"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={resumeScoreDistribution}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                    <XAxis dataKey="range" stroke="var(--color-muted-foreground)" fontSize={12} />
                    <YAxis stroke="var(--color-muted-foreground)" fontSize={12} />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Bar dataKey="count" fill="var(--color-accent)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>

          {/* CGPA Distribution */}
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle>CGPA Distribution</CardTitle>
              <CardDescription>Academic performance distribution</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  count: { label: "Students", color: "var(--color-primary)" },
                }}
                className="h-[250px]"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={cgpaDistribution}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                    <XAxis dataKey="range" stroke="var(--color-muted-foreground)" fontSize={12} />
                    <YAxis stroke="var(--color-muted-foreground)" fontSize={12} />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Bar dataKey="count" fill="var(--color-primary)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>
        </div>

        {/* Department Performance */}
        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle>Department-wise Performance</CardTitle>
            <CardDescription>Placement statistics and performance by department</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {analyticsData.departmentWisePlacement.map((dept) => {
                const percentage = ((dept.placed / dept.total) * 100).toFixed(0)
                return (
                  <Card key={dept.department} className="border-border bg-secondary/30">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/20 text-primary">
                          <GraduationCap className="h-5 w-5" />
                        </div>
                        <div>
                          <p className="text-sm font-medium text-foreground">{dept.department}</p>
                          <p className="text-xs text-muted-foreground">{dept.total} students</p>
                        </div>
                      </div>
                      <div className="mt-4">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">Placed</span>
                          <span className="font-bold text-foreground">{dept.placed}</span>
                        </div>
                        <Progress value={Number(percentage)} className="mt-2 h-2" />
                        <p className="mt-1 text-center text-xs text-muted-foreground">
                          {percentage}% placement rate
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </CardContent>
        </Card>

        {/* Additional Metrics */}
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          <Card className="border-border bg-card">
            <CardContent className="flex items-center gap-4 p-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/20 text-primary">
                <Calendar className="h-6 w-6" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{analyticsData.averageAttendance}%</p>
                <p className="text-sm text-muted-foreground">Avg. Attendance</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-border bg-card">
            <CardContent className="flex items-center gap-4 p-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-accent/20 text-accent">
                <Award className="h-6 w-6" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">
                  {students.reduce((sum, s) => sum + s.certificates.length, 0)}
                </p>
                <p className="text-sm text-muted-foreground">Total Certificates</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-border bg-card">
            <CardContent className="flex items-center gap-4 p-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-warning/20 text-warning">
                <Target className="h-6 w-6" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">
                  {students.reduce((sum, s) => sum + s.appliedJobs.length, 0)}
                </p>
                <p className="text-sm text-muted-foreground">Total Applications</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-border bg-card">
            <CardContent className="flex items-center gap-4 p-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-muted text-muted-foreground">
                <CheckCircle className="h-6 w-6" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">
                  {students.filter((s) => s.resumeCompleted >= 80).length}
                </p>
                <p className="text-sm text-muted-foreground">Complete Resumes</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
