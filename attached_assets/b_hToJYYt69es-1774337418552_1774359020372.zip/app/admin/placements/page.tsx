"use client"

import { useState } from "react"
import { DashboardHeader } from "@/components/dashboard/header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"
import { students, jobs } from "@/lib/data"
import type { Student } from "@/lib/types"
import {
  Search,
  Filter,
  Users,
  CheckCircle,
  Clock,
  TrendingUp,
  Building,
  Edit2,
  Save,
} from "lucide-react"

export default function PlacementsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [studentsData, setStudentsData] = useState(students)
  const [editingStudent, setEditingStudent] = useState<Student | null>(null)
  const [newStatus, setNewStatus] = useState<string>("")
  const [newCompany, setNewCompany] = useState<string>("")

  const filteredStudents = studentsData.filter((student) => {
    const matchesSearch =
      student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.rollNumber.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesStatus =
      statusFilter === "all" || student.placementStatus === statusFilter
    return matchesSearch && matchesStatus
  })

  const handleUpdateStatus = () => {
    if (editingStudent && newStatus) {
      setStudentsData(
        studentsData.map((s) =>
          s.id === editingStudent.id
            ? {
                ...s,
                placementStatus: newStatus as Student["placementStatus"],
                companyPlaced: newStatus === "placed" ? newCompany : undefined,
              }
            : s
        )
      )
      setEditingStudent(null)
      setNewStatus("")
      setNewCompany("")
    }
  }

  const placedCount = studentsData.filter((s) => s.placementStatus === "placed").length
  const shortlistedCount = studentsData.filter((s) => s.placementStatus === "shortlisted").length
  const appliedCount = studentsData.filter((s) => s.placementStatus === "applied").length

  const statusColors = {
    placed: "bg-accent text-accent-foreground",
    shortlisted: "bg-warning/20 text-warning",
    applied: "bg-primary/20 text-primary",
    "not-applied": "bg-muted text-muted-foreground",
  }

  return (
    <div className="flex flex-col">
      <DashboardHeader
        title="Placement Management"
        description="Update and track student placement status"
      />

      <div className="flex-1 space-y-6 p-6">
        {/* Stats */}
        <div className="grid gap-4 sm:grid-cols-4">
          <Card className="border-border bg-card">
            <CardContent className="flex items-center gap-4 p-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/20 text-accent">
                <CheckCircle className="h-5 w-5" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{placedCount}</p>
                <p className="text-xs text-muted-foreground">Placed</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-border bg-card">
            <CardContent className="flex items-center gap-4 p-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-warning/20 text-warning">
                <TrendingUp className="h-5 w-5" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{shortlistedCount}</p>
                <p className="text-xs text-muted-foreground">Shortlisted</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-border bg-card">
            <CardContent className="flex items-center gap-4 p-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/20 text-primary">
                <Clock className="h-5 w-5" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{appliedCount}</p>
                <p className="text-xs text-muted-foreground">Applied</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-border bg-card">
            <CardContent className="flex items-center gap-4 p-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted text-muted-foreground">
                <Users className="h-5 w-5" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">
                  {studentsData.length - placedCount - shortlistedCount - appliedCount}
                </p>
                <p className="text-xs text-muted-foreground">Not Applied</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="border-border bg-card">
          <CardContent className="p-4">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search students..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[180px]">
                  <Filter className="mr-2 h-4 w-4" />
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="placed">Placed</SelectItem>
                  <SelectItem value="shortlisted">Shortlisted</SelectItem>
                  <SelectItem value="applied">Applied</SelectItem>
                  <SelectItem value="not-applied">Not Applied</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Students Table */}
        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle>Student Placements</CardTitle>
            <CardDescription>Update placement status for students</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead>Department</TableHead>
                    <TableHead>CGPA</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Company</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredStudents.map((student) => (
                    <TableRow key={student.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium text-foreground">{student.name}</p>
                          <p className="text-sm text-muted-foreground">{student.rollNumber}</p>
                        </div>
                      </TableCell>
                      <TableCell>{student.department}</TableCell>
                      <TableCell>{student.cgpa.toFixed(1)}</TableCell>
                      <TableCell>
                        <Badge className={statusColors[student.placementStatus]}>
                          {student.placementStatus === "not-applied"
                            ? "Not Applied"
                            : student.placementStatus.charAt(0).toUpperCase() +
                              student.placementStatus.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {student.companyPlaced ? (
                          <div className="flex items-center gap-2">
                            <Building className="h-4 w-4 text-muted-foreground" />
                            {student.companyPlaced}
                          </div>
                        ) : (
                          <span className="text-muted-foreground">-</span>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setEditingStudent(student)
                                setNewStatus(student.placementStatus)
                                setNewCompany(student.companyPlaced || "")
                              }}
                            >
                              <Edit2 className="mr-2 h-4 w-4" />
                              Update
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Update Placement Status</DialogTitle>
                              <DialogDescription>
                                Update the placement status for {student.name}
                              </DialogDescription>
                            </DialogHeader>
                            <div className="space-y-4 py-4">
                              <div className="space-y-2">
                                <label className="text-sm font-medium text-foreground">
                                  Status
                                </label>
                                <Select value={newStatus} onValueChange={setNewStatus}>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select status" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="not-applied">Not Applied</SelectItem>
                                    <SelectItem value="applied">Applied</SelectItem>
                                    <SelectItem value="shortlisted">Shortlisted</SelectItem>
                                    <SelectItem value="placed">Placed</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              {newStatus === "placed" && (
                                <div className="space-y-2">
                                  <label className="text-sm font-medium text-foreground">
                                    Company Name
                                  </label>
                                  <Input
                                    placeholder="Enter company name"
                                    value={newCompany}
                                    onChange={(e) => setNewCompany(e.target.value)}
                                  />
                                </div>
                              )}
                            </div>
                            <DialogFooter>
                              <Button onClick={handleUpdateStatus}>
                                <Save className="mr-2 h-4 w-4" />
                                Save Changes
                              </Button>
                            </DialogFooter>
                          </DialogContent>
                        </Dialog>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
