"use client"

import { useState } from "react"
import { DashboardHeader } from "@/components/dashboard/header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { students } from "@/lib/data"
import type { Student } from "@/lib/types"
import {
  Search,
  Filter,
  Users,
  Eye,
  Mail,
  Phone,
  GraduationCap,
  Calendar,
  FileText,
  Award,
  Download,
} from "lucide-react"

export default function StudentsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [departmentFilter, setDepartmentFilter] = useState<string>("all")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null)

  const departments = [...new Set(students.map((s) => s.department))]

  const filteredStudents = students.filter((student) => {
    const matchesSearch =
      student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.rollNumber.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesDepartment =
      departmentFilter === "all" || student.department === departmentFilter
    const matchesStatus =
      statusFilter === "all" || student.placementStatus === statusFilter
    return matchesSearch && matchesDepartment && matchesStatus
  })

  const statusColors = {
    placed: "bg-accent text-accent-foreground",
    shortlisted: "bg-warning/20 text-warning",
    applied: "bg-primary/20 text-primary",
    "not-applied": "bg-muted text-muted-foreground",
  }

  return (
    <div className="flex flex-col">
      <DashboardHeader
        title="Student Management"
        description="View and manage all registered students"
      />

      <div className="flex-1 space-y-6 p-6">
        {/* Stats */}
        <div className="grid gap-4 sm:grid-cols-4">
          <Card className="border-border bg-card">
            <CardContent className="flex items-center gap-4 p-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/20 text-primary">
                <Users className="h-5 w-5" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{students.length}</p>
                <p className="text-xs text-muted-foreground">Total Students</p>
              </div>
            </CardContent>
          </Card>
          {departments.slice(0, 3).map((dept) => (
            <Card key={dept} className="border-border bg-card">
              <CardContent className="flex items-center gap-4 p-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-secondary text-secondary-foreground">
                  <GraduationCap className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">
                    {students.filter((s) => s.department === dept).length}
                  </p>
                  <p className="text-xs text-muted-foreground">{dept}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Filters */}
        <Card className="border-border bg-card">
          <CardContent className="p-4">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search by name, email, or roll number..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <div className="flex gap-2">
                <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
                  <SelectTrigger className="w-[180px]">
                    <Filter className="mr-2 h-4 w-4" />
                    <SelectValue placeholder="Department" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Departments</SelectItem>
                    {departments.map((dept) => (
                      <SelectItem key={dept} value={dept}>
                        {dept}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="placed">Placed</SelectItem>
                    <SelectItem value="shortlisted">Shortlisted</SelectItem>
                    <SelectItem value="applied">Applied</SelectItem>
                    <SelectItem value="not-applied">Not Applied</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline">
                  <Download className="mr-2 h-4 w-4" />
                  Export
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Students Table */}
        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle>Students ({filteredStudents.length})</CardTitle>
            <CardDescription>Complete list of registered students</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead>Department</TableHead>
                    <TableHead>CGPA</TableHead>
                    <TableHead>Attendance</TableHead>
                    <TableHead>Resume</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredStudents.map((student) => (
                    <TableRow key={student.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/20 text-primary">
                            <Users className="h-5 w-5" />
                          </div>
                          <div>
                            <p className="font-medium text-foreground">{student.name}</p>
                            <p className="text-sm text-muted-foreground">{student.rollNumber}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{student.department}</Badge>
                      </TableCell>
                      <TableCell>
                        <span className={student.cgpa >= 7 ? "text-accent" : "text-warning"}>
                          {student.cgpa.toFixed(1)}
                        </span>
                      </TableCell>
                      <TableCell>
                        <span className={student.attendance >= 75 ? "text-accent" : "text-destructive"}>
                          {student.attendance}%
                        </span>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div className="h-2 w-16 rounded-full bg-muted">
                            <div
                              className="h-full rounded-full bg-primary"
                              style={{ width: `${student.resumeCompleted}%` }}
                            />
                          </div>
                          <span className="text-xs text-muted-foreground">
                            {student.resumeCompleted}%
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={statusColors[student.placementStatus]}>
                          {student.placementStatus === "not-applied"
                            ? "Not Applied"
                            : student.placementStatus.charAt(0).toUpperCase() +
                              student.placementStatus.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setSelectedStudent(student)}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-2xl">
                            <DialogHeader>
                              <DialogTitle>{student.name}</DialogTitle>
                              <DialogDescription>{student.rollNumber}</DialogDescription>
                            </DialogHeader>
                            <div className="grid gap-6 py-4">
                              <div className="grid gap-4 sm:grid-cols-2">
                                <div className="space-y-1">
                                  <p className="text-sm text-muted-foreground">Email</p>
                                  <p className="flex items-center gap-2 text-foreground">
                                    <Mail className="h-4 w-4" />
                                    {student.email}
                                  </p>
                                </div>
                                <div className="space-y-1">
                                  <p className="text-sm text-muted-foreground">Phone</p>
                                  <p className="flex items-center gap-2 text-foreground">
                                    <Phone className="h-4 w-4" />
                                    {student.phone}
                                  </p>
                                </div>
                                <div className="space-y-1">
                                  <p className="text-sm text-muted-foreground">Department</p>
                                  <p className="flex items-center gap-2 text-foreground">
                                    <GraduationCap className="h-4 w-4" />
                                    {student.department}
                                  </p>
                                </div>
                                <div className="space-y-1">
                                  <p className="text-sm text-muted-foreground">Semester</p>
                                  <p className="flex items-center gap-2 text-foreground">
                                    <Calendar className="h-4 w-4" />
                                    Semester {student.semester}
                                  </p>
                                </div>
                              </div>
                              <div className="grid gap-4 sm:grid-cols-4">
                                <Card className="border-border bg-secondary/30">
                                  <CardContent className="p-3 text-center">
                                    <p className="text-2xl font-bold text-primary">
                                      {student.cgpa.toFixed(1)}
                                    </p>
                                    <p className="text-xs text-muted-foreground">CGPA</p>
                                  </CardContent>
                                </Card>
                                <Card className="border-border bg-secondary/30">
                                  <CardContent className="p-3 text-center">
                                    <p className="text-2xl font-bold text-accent">
                                      {student.attendance}%
                                    </p>
                                    <p className="text-xs text-muted-foreground">Attendance</p>
                                  </CardContent>
                                </Card>
                                <Card className="border-border bg-secondary/30">
                                  <CardContent className="p-3 text-center">
                                    <p className="text-2xl font-bold text-warning">
                                      {student.resumeScore || 0}
                                    </p>
                                    <p className="text-xs text-muted-foreground">Resume Score</p>
                                  </CardContent>
                                </Card>
                                <Card className="border-border bg-secondary/30">
                                  <CardContent className="p-3 text-center">
                                    <p className="text-2xl font-bold text-foreground">
                                      {student.certificates.length}
                                    </p>
                                    <p className="text-xs text-muted-foreground">Certificates</p>
                                  </CardContent>
                                </Card>
                              </div>
                              <div>
                                <p className="mb-2 text-sm font-medium text-foreground">Skills</p>
                                <div className="flex flex-wrap gap-2">
                                  {student.skills.map((skill) => (
                                    <Badge key={skill} variant="secondary">
                                      {skill}
                                    </Badge>
                                  ))}
                                </div>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
