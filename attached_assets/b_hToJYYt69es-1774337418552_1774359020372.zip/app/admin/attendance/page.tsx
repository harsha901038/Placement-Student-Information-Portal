"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Progress } from "@/components/ui/progress"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  CalendarCheck,
  CalendarX,
  Users,
  TrendingUp,
  Search,
  Filter,
  Download,
  Eye,
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
  CheckCircle,
  XCircle,
  Clock,
} from "lucide-react"

// Mock data for admin attendance view
const departmentStats = [
  { department: "Computer Science", totalStudents: 120, avgAttendance: 87.5 },
  { department: "Electronics", totalStudents: 95, avgAttendance: 82.3 },
  { department: "Mechanical", totalStudents: 85, avgAttendance: 79.8 },
  { department: "Civil", totalStudents: 75, avgAttendance: 84.2 },
  { department: "Electrical", totalStudents: 80, avgAttendance: 81.5 },
]

const studentAttendanceData = [
  { id: "STU001", name: "Rahul Sharma", department: "Computer Science", semester: 6, attendance: 92.5, classes: "42/45", status: "good" },
  { id: "STU002", name: "Priya Patel", department: "Computer Science", semester: 6, attendance: 88.0, classes: "40/45", status: "good" },
  { id: "STU003", name: "Amit Kumar", department: "Electronics", semester: 4, attendance: 74.5, classes: "32/43", status: "warning" },
  { id: "STU004", name: "Sneha Reddy", department: "Computer Science", semester: 6, attendance: 68.2, classes: "30/44", status: "critical" },
  { id: "STU005", name: "Vikram Singh", department: "Mechanical", semester: 4, attendance: 85.3, classes: "35/41", status: "good" },
  { id: "STU006", name: "Ananya Gupta", department: "Civil", semester: 6, attendance: 91.0, classes: "41/45", status: "good" },
  { id: "STU007", name: "Rohit Verma", department: "Electrical", semester: 4, attendance: 72.0, classes: "31/43", status: "warning" },
  { id: "STU008", name: "Kavya Nair", department: "Electronics", semester: 6, attendance: 65.5, classes: "29/44", status: "critical" },
  { id: "STU009", name: "Arjun Das", department: "Computer Science", semester: 4, attendance: 89.5, classes: "38/42", status: "good" },
  { id: "STU010", name: "Meera Iyer", department: "Mechanical", semester: 6, attendance: 78.0, classes: "35/45", status: "warning" },
]

const months = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
]

export default function AdminAttendancePage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedDepartment, setSelectedDepartment] = useState("all")
  const [selectedStatus, setSelectedStatus] = useState("all")
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth())
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear())
  const [selectedStudent, setSelectedStudent] = useState<typeof studentAttendanceData[0] | null>(null)

  const filteredStudents = studentAttendanceData.filter((student) => {
    const matchesSearch =
      student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.id.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesDepartment =
      selectedDepartment === "all" || student.department === selectedDepartment
    const matchesStatus = selectedStatus === "all" || student.status === selectedStatus
    return matchesSearch && matchesDepartment && matchesStatus
  })

  const totalStudents = studentAttendanceData.length
  const studentsAbove85 = studentAttendanceData.filter((s) => s.attendance >= 85).length
  const studentsBelow75 = studentAttendanceData.filter((s) => s.attendance < 75).length
  const avgAttendance =
    studentAttendanceData.reduce((acc, s) => acc + s.attendance, 0) / totalStudents

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "good":
        return <Badge className="bg-success/20 text-success hover:bg-success/30">Good</Badge>
      case "warning":
        return <Badge className="bg-warning/20 text-warning-foreground hover:bg-warning/30">Warning</Badge>
      case "critical":
        return <Badge className="bg-destructive/20 text-destructive hover:bg-destructive/30">Critical</Badge>
      default:
        return null
    }
  }

  const getPercentageColor = (percentage: number) => {
    if (percentage >= 85) return "text-success"
    if (percentage >= 75) return "text-warning"
    return "text-destructive"
  }

  const handlePrevMonth = () => {
    if (selectedMonth === 0) {
      setSelectedMonth(11)
      setSelectedYear(selectedYear - 1)
    } else {
      setSelectedMonth(selectedMonth - 1)
    }
  }

  const handleNextMonth = () => {
    if (selectedMonth === 11) {
      setSelectedMonth(0)
      setSelectedYear(selectedYear + 1)
    } else {
      setSelectedMonth(selectedMonth + 1)
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Attendance Management</h1>
          <p className="text-muted-foreground">Monitor and manage student attendance across departments</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Export Report
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="border-border bg-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Average Attendance</p>
                <p className={`text-2xl font-bold ${getPercentageColor(avgAttendance)}`}>
                  {avgAttendance.toFixed(1)}%
                </p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/20">
                <TrendingUp className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border bg-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Students</p>
                <p className="text-2xl font-bold text-foreground">{totalStudents}</p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted">
                <Users className="h-6 w-6 text-muted-foreground" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border bg-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Above 85%</p>
                <p className="text-2xl font-bold text-success">{studentsAbove85}</p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-success/20">
                <CalendarCheck className="h-6 w-6 text-success" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border bg-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Below 75%</p>
                <p className="text-2xl font-bold text-destructive">{studentsBelow75}</p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-destructive/20">
                <AlertTriangle className="h-6 w-6 text-destructive" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Department Stats */}
      <Card className="border-border bg-card">
        <CardHeader>
          <CardTitle className="text-lg">Department-wise Attendance</CardTitle>
          <CardDescription>Average attendance by department</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {departmentStats.map((dept) => (
              <div key={dept.department} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-foreground">{dept.department}</span>
                    <Badge variant="secondary" className="text-xs">
                      {dept.totalStudents} students
                    </Badge>
                  </div>
                  <span className={`text-sm font-bold ${getPercentageColor(dept.avgAttendance)}`}>
                    {dept.avgAttendance.toFixed(1)}%
                  </span>
                </div>
                <Progress
                  value={dept.avgAttendance}
                  className={`h-2 ${
                    dept.avgAttendance >= 85
                      ? "[&>div]:bg-success"
                      : dept.avgAttendance >= 75
                      ? "[&>div]:bg-warning"
                      : "[&>div]:bg-destructive"
                  }`}
                />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Student Attendance Table */}
      <Card className="border-border bg-card">
        <CardHeader>
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <CardTitle className="text-lg">Student Attendance Records</CardTitle>
              <CardDescription>View and manage individual student attendance</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" onClick={handlePrevMonth}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span className="min-w-[140px] text-center text-sm font-medium">
                {months[selectedMonth]} {selectedYear}
              </span>
              <Button variant="ghost" size="icon" onClick={handleNextMonth}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Filters */}
          <div className="mb-6 flex flex-col gap-4 sm:flex-row">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search by name or ID..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="Department" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Departments</SelectItem>
                <SelectItem value="Computer Science">Computer Science</SelectItem>
                <SelectItem value="Electronics">Electronics</SelectItem>
                <SelectItem value="Mechanical">Mechanical</SelectItem>
                <SelectItem value="Civil">Civil</SelectItem>
                <SelectItem value="Electrical">Electrical</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="w-full sm:w-[140px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="good">Good</SelectItem>
                <SelectItem value="warning">Warning</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Table */}
          <div className="rounded-lg border border-border">
            <Table>
              <TableHeader>
                <TableRow className="border-border hover:bg-transparent">
                  <TableHead className="text-muted-foreground">Student ID</TableHead>
                  <TableHead className="text-muted-foreground">Name</TableHead>
                  <TableHead className="text-muted-foreground">Department</TableHead>
                  <TableHead className="text-muted-foreground">Semester</TableHead>
                  <TableHead className="text-muted-foreground">Classes</TableHead>
                  <TableHead className="text-muted-foreground">Attendance</TableHead>
                  <TableHead className="text-muted-foreground">Status</TableHead>
                  <TableHead className="text-muted-foreground">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredStudents.map((student) => (
                  <TableRow key={student.id} className="border-border">
                    <TableCell className="font-mono text-sm">{student.id}</TableCell>
                    <TableCell className="font-medium">{student.name}</TableCell>
                    <TableCell className="text-muted-foreground">{student.department}</TableCell>
                    <TableCell className="text-muted-foreground">{student.semester}</TableCell>
                    <TableCell className="text-muted-foreground">{student.classes}</TableCell>
                    <TableCell>
                      <span className={`font-bold ${getPercentageColor(student.attendance)}`}>
                        {student.attendance.toFixed(1)}%
                      </span>
                    </TableCell>
                    <TableCell>{getStatusBadge(student.status)}</TableCell>
                    <TableCell>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setSelectedStudent(student)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="sm:max-w-[500px]">
                          <DialogHeader>
                            <DialogTitle>Attendance Details</DialogTitle>
                            <DialogDescription>
                              Detailed attendance record for {student.name}
                            </DialogDescription>
                          </DialogHeader>
                          <div className="space-y-6 py-4">
                            <div className="flex items-center gap-4">
                              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/20 text-primary">
                                <span className="text-xl font-bold">
                                  {student.name.split(" ").map((n) => n[0]).join("")}
                                </span>
                              </div>
                              <div>
                                <p className="font-medium text-foreground">{student.name}</p>
                                <p className="text-sm text-muted-foreground">{student.id}</p>
                                <p className="text-sm text-muted-foreground">
                                  {student.department} - Semester {student.semester}
                                </p>
                              </div>
                            </div>

                            <div className="grid gap-4 sm:grid-cols-3">
                              <div className="rounded-lg bg-secondary/50 p-4 text-center">
                                <CheckCircle className="mx-auto h-6 w-6 text-success" />
                                <p className="mt-2 text-2xl font-bold text-foreground">
                                  {student.classes.split("/")[0]}
                                </p>
                                <p className="text-xs text-muted-foreground">Present</p>
                              </div>
                              <div className="rounded-lg bg-secondary/50 p-4 text-center">
                                <XCircle className="mx-auto h-6 w-6 text-destructive" />
                                <p className="mt-2 text-2xl font-bold text-foreground">
                                  {parseInt(student.classes.split("/")[1]) -
                                    parseInt(student.classes.split("/")[0])}
                                </p>
                                <p className="text-xs text-muted-foreground">Absent</p>
                              </div>
                              <div className="rounded-lg bg-secondary/50 p-4 text-center">
                                <Clock className="mx-auto h-6 w-6 text-muted-foreground" />
                                <p className="mt-2 text-2xl font-bold text-foreground">
                                  {student.classes.split("/")[1]}
                                </p>
                                <p className="text-xs text-muted-foreground">Total</p>
                              </div>
                            </div>

                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <span className="text-sm text-muted-foreground">
                                  Overall Attendance
                                </span>
                                <span
                                  className={`text-lg font-bold ${getPercentageColor(
                                    student.attendance
                                  )}`}
                                >
                                  {student.attendance.toFixed(1)}%
                                </span>
                              </div>
                              <Progress
                                value={student.attendance}
                                className={`h-3 ${
                                  student.attendance >= 85
                                    ? "[&>div]:bg-success"
                                    : student.attendance >= 75
                                    ? "[&>div]:bg-warning"
                                    : "[&>div]:bg-destructive"
                                }`}
                              />
                            </div>

                            {student.attendance < 75 && (
                              <div className="rounded-lg border border-destructive/50 bg-destructive/10 p-4">
                                <div className="flex items-center gap-2">
                                  <AlertTriangle className="h-5 w-5 text-destructive" />
                                  <span className="font-medium text-destructive">
                                    Critical Attendance
                                  </span>
                                </div>
                                <p className="mt-1 text-sm text-muted-foreground">
                                  Student may not be eligible for examinations. Consider
                                  scheduling a counseling session.
                                </p>
                              </div>
                            )}
                          </div>
                        </DialogContent>
                      </Dialog>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {filteredStudents.length === 0 && (
            <div className="py-12 text-center">
              <p className="text-muted-foreground">No students found matching your criteria.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
