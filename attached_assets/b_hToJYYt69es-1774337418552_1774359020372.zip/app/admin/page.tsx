"use client"

import { DashboardHeader } from "@/components/dashboard/header"
import { StatsCard } from "@/components/dashboard/stats-card"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { analyticsData, students, jobs, announcements } from "@/lib/data"
import {
  Users,
  Briefcase,
  GraduationCap,
  FileText,
  TrendingUp,
  Bell,
  ArrowRight,
  Building,
  CheckCircle,
  Clock,
  BarChart3,
} from "lucide-react"
import Link from "next/link"
import { Bar, BarChart, Line, LineChart, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Cell } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

const placementRate = ((analyticsData.placedStudents / analyticsData.totalStudents) * 100).toFixed(1)

export default function AdminDashboard() {
  return (
    <div className="flex flex-col">
      <DashboardHeader
        title="Admin Dashboard"
        description="Overview of placement activities and student performance"
      />

      <div className="flex-1 space-y-6 p-6">
        {/* Stats Grid */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatsCard
            title="Total Students"
            value={analyticsData.totalStudents}
            subtitle="Registered students"
            icon={Users}
            variant="primary"
          />
          <StatsCard
            title="Placed Students"
            value={analyticsData.placedStudents}
            subtitle={`${placementRate}% placement rate`}
            icon={CheckCircle}
            variant="accent"
          />
          <StatsCard
            title="Average CGPA"
            value={analyticsData.averageCGPA.toFixed(2)}
            subtitle="Overall average"
            icon={GraduationCap}
            variant="primary"
          />
          <StatsCard
            title="Resume Completion"
            value={`${analyticsData.resumeCompletionRate}%`}
            subtitle="Average completion"
            icon={FileText}
            variant="warning"
          />
        </div>

        {/* Charts Row */}
        <div className="grid gap-6 lg:grid-cols-2">
          {/* Monthly Placements Chart */}
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle>Monthly Placements</CardTitle>
              <CardDescription>Placement trends over the past 6 months</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  count: { label: "Placements", color: "var(--color-primary)" },
                }}
                className="h-[300px]"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={analyticsData.monthlyPlacements}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                    <XAxis dataKey="month" stroke="var(--color-muted-foreground)" fontSize={12} />
                    <YAxis stroke="var(--color-muted-foreground)" fontSize={12} />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Bar dataKey="count" fill="var(--color-primary)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>

          {/* Department-wise Placements */}
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle>Department-wise Placements</CardTitle>
              <CardDescription>Placement statistics by department</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-5">
                {analyticsData.departmentWisePlacement.map((dept) => {
                  const percentage = ((dept.placed / dept.total) * 100).toFixed(0)
                  return (
                    <div key={dept.department} className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="min-w-0 truncate font-medium text-foreground">{dept.department}</span>
                        <span className="ml-2 shrink-0 text-muted-foreground">
                          {dept.placed}/{dept.total} ({percentage}%)
                        </span>
                      </div>
                      <Progress value={Number(percentage)} className="h-2.5" />
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Recent Students */}
          <Card className="border-border bg-card lg:col-span-2">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Recent Students</CardTitle>
                <CardDescription>Latest registered students</CardDescription>
              </div>
              <Link href="/admin/students">
                <Button variant="ghost" size="sm">
                  View All <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {students.slice(0, 5).map((student) => (
                  <div
                    key={student.id}
                    className="flex items-center justify-between rounded-lg border border-border bg-secondary/30 p-4"
                  >
                    <div className="flex items-center gap-4">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/20 text-primary">
                        <Users className="h-5 w-5" />
                      </div>
                      <div>
                        <p className="font-medium text-foreground">{student.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {student.department} • {student.rollNumber}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge variant="outline">CGPA: {student.cgpa}</Badge>
                      <Badge
                        className={
                          student.placementStatus === "placed"
                            ? "bg-accent text-accent-foreground"
                            : student.placementStatus === "shortlisted"
                            ? "bg-warning/20 text-warning"
                            : student.placementStatus === "applied"
                            ? "bg-primary/20 text-primary"
                            : "bg-muted text-muted-foreground"
                        }
                      >
                        {student.placementStatus === "placed"
                          ? "Placed"
                          : student.placementStatus === "shortlisted"
                          ? "Shortlisted"
                          : student.placementStatus === "applied"
                          ? "Applied"
                          : "Not Applied"}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions & Announcements */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="grid gap-2">
                <Link href="/admin/students">
                  <Button variant="outline" className="w-full justify-start">
                    <Users className="mr-2 h-4 w-4" />
                    Manage Students
                  </Button>
                </Link>
                <Link href="/admin/placements">
                  <Button variant="outline" className="w-full justify-start">
                    <Briefcase className="mr-2 h-4 w-4" />
                    Update Placements
                  </Button>
                </Link>
                <Link href="/admin/resumes">
                  <Button variant="outline" className="w-full justify-start">
                    <FileText className="mr-2 h-4 w-4" />
                    Review Resumes
                  </Button>
                </Link>
                <Link href="/admin/announcements">
                  <Button variant="outline" className="w-full justify-start">
                    <Bell className="mr-2 h-4 w-4" />
                    Send Announcement
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Recent Announcements */}
            <Card className="border-border bg-card">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Recent Announcements</CardTitle>
                <Link href="/admin/announcements">
                  <Button variant="ghost" size="sm">
                    View All
                  </Button>
                </Link>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {announcements.slice(0, 3).map((announcement) => (
                    <div key={announcement.id} className="space-y-1">
                      <div className="flex items-center gap-2">
                        <Badge
                          variant="outline"
                          className={
                            announcement.priority === "high"
                              ? "border-destructive text-destructive"
                              : announcement.priority === "medium"
                              ? "border-warning text-warning"
                              : ""
                          }
                        >
                          {announcement.priority}
                        </Badge>
                        <span className="text-xs text-muted-foreground">{announcement.date}</span>
                      </div>
                      <p className="text-sm font-medium text-foreground">{announcement.title}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Open Jobs */}
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle>Active Opportunities</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {jobs
                    .filter((j) => j.status === "open")
                    .slice(0, 3)
                    .map((job) => (
                      <div key={job.id} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Building className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm text-foreground">{job.title}</span>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {job.applicants} applied
                        </Badge>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
