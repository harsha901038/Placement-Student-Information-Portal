"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  CalendarCheck,
  CalendarX,
  Clock,
  TrendingUp,
  ChevronLeft,
  ChevronRight,
  AlertTriangle,
} from "lucide-react"

// Mock attendance data
const attendanceData = {
  overall: {
    totalClasses: 180,
    attended: 156,
    percentage: 86.7,
  },
  subjects: [
    { name: "Data Structures", code: "CS301", total: 45, attended: 42, percentage: 93.3 },
    { name: "Database Systems", code: "CS302", total: 40, attended: 36, percentage: 90.0 },
    { name: "Operating Systems", code: "CS303", total: 35, attended: 30, percentage: 85.7 },
    { name: "Computer Networks", code: "CS304", total: 30, attended: 24, percentage: 80.0 },
    { name: "Software Engineering", code: "CS305", total: 30, attended: 24, percentage: 80.0 },
  ],
  monthlyData: [
    { month: "January", attended: 22, total: 24 },
    { month: "February", attended: 20, total: 22 },
    { month: "March", attended: 24, total: 26 },
    { month: "April", attended: 18, total: 20 },
    { month: "May", attended: 22, total: 24 },
    { month: "June", attended: 26, total: 28 },
  ],
}

// Generate calendar data for current month
const generateCalendarData = (year: number, month: number) => {
  const firstDay = new Date(year, month, 1)
  const lastDay = new Date(year, month + 1, 0)
  const daysInMonth = lastDay.getDate()
  const startingDay = firstDay.getDay()

  const days = []

  // Add empty days for padding
  for (let i = 0; i < startingDay; i++) {
    days.push({ day: null, status: null })
  }

  // Add days with random attendance status
  for (let i = 1; i <= daysInMonth; i++) {
    const dayOfWeek = new Date(year, month, i).getDay()
    if (dayOfWeek === 0 || dayOfWeek === 6) {
      days.push({ day: i, status: "weekend" })
    } else {
      const rand = Math.random()
      if (rand > 0.15) {
        days.push({ day: i, status: "present" })
      } else if (rand > 0.05) {
        days.push({ day: i, status: "absent" })
      } else {
        days.push({ day: i, status: "late" })
      }
    }
  }

  return days
}

const months = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
]

export default function StudentAttendancePage() {
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth())
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear())
  const [selectedSubject, setSelectedSubject] = useState("all")

  const calendarDays = generateCalendarData(selectedYear, selectedMonth)

  const handlePrevMonth = () => {
    if (selectedMonth === 0) {
      setSelectedMonth(11)
      setSelectedYear(selectedYear - 1)
    } else {
      setSelectedMonth(selectedMonth - 1)
    }
  }

  const handleNextMonth = () => {
    if (selectedMonth === 11) {
      setSelectedMonth(0)
      setSelectedYear(selectedYear + 1)
    } else {
      setSelectedMonth(selectedMonth + 1)
    }
  }

  const getStatusColor = (status: string | null) => {
    switch (status) {
      case "present":
        return "bg-success/20 text-success"
      case "absent":
        return "bg-destructive/20 text-destructive"
      case "late":
        return "bg-warning/20 text-warning-foreground"
      case "weekend":
        return "bg-muted/50 text-muted-foreground"
      default:
        return ""
    }
  }

  const getPercentageColor = (percentage: number) => {
    if (percentage >= 85) return "text-success"
    if (percentage >= 75) return "text-warning"
    return "text-destructive"
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">Attendance</h1>
        <p className="text-muted-foreground">Track your class attendance and statistics</p>
      </div>

      {/* Overall Stats */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="border-border bg-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Overall Attendance</p>
                <p className={`text-2xl font-bold ${getPercentageColor(attendanceData.overall.percentage)}`}>
                  {attendanceData.overall.percentage}%
                </p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/20">
                <TrendingUp className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border bg-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Classes Attended</p>
                <p className="text-2xl font-bold text-foreground">{attendanceData.overall.attended}</p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-success/20">
                <CalendarCheck className="h-6 w-6 text-success" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border bg-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Classes Missed</p>
                <p className="text-2xl font-bold text-foreground">
                  {attendanceData.overall.totalClasses - attendanceData.overall.attended}
                </p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-destructive/20">
                <CalendarX className="h-6 w-6 text-destructive" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border bg-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Classes</p>
                <p className="text-2xl font-bold text-foreground">{attendanceData.overall.totalClasses}</p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted">
                <Clock className="h-6 w-6 text-muted-foreground" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Warning if attendance is low */}
      {attendanceData.overall.percentage < 75 && (
        <Card className="border-destructive/50 bg-destructive/10">
          <CardContent className="flex items-center gap-4 p-4">
            <AlertTriangle className="h-6 w-6 text-destructive" />
            <div>
              <p className="font-medium text-destructive">Low Attendance Warning</p>
              <p className="text-sm text-muted-foreground">
                Your attendance is below 75%. You may not be eligible for exams.
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Calendar View */}
        <Card className="border-border bg-card">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Attendance Calendar</CardTitle>
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon" onClick={handlePrevMonth}>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <span className="min-w-[140px] text-center text-sm font-medium">
                  {months[selectedMonth]} {selectedYear}
                </span>
                <Button variant="ghost" size="icon" onClick={handleNextMonth}>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-7 gap-1">
              {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
                <div key={day} className="p-2 text-center text-xs font-medium text-muted-foreground">
                  {day}
                </div>
              ))}
              {calendarDays.map((day, index) => (
                <div
                  key={index}
                  className={`flex h-10 items-center justify-center rounded-md text-sm ${
                    day.day ? getStatusColor(day.status) : ""
                  }`}
                >
                  {day.day}
                </div>
              ))}
            </div>
            <div className="mt-4 flex flex-wrap items-center gap-4 text-xs">
              <div className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-full bg-success/50" />
                <span className="text-muted-foreground">Present</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-full bg-destructive/50" />
                <span className="text-muted-foreground">Absent</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-full bg-warning/50" />
                <span className="text-muted-foreground">Late</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-full bg-muted/50" />
                <span className="text-muted-foreground">Weekend</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Subject-wise Attendance */}
        <Card className="border-border bg-card">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg">Subject-wise Attendance</CardTitle>
                <CardDescription>Attendance breakdown by subject</CardDescription>
              </div>
              <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Filter" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Subjects</SelectItem>
                  <SelectItem value="low">Below 85%</SelectItem>
                  <SelectItem value="critical">Below 75%</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {attendanceData.subjects
              .filter((subject) => {
                if (selectedSubject === "low") return subject.percentage < 85
                if (selectedSubject === "critical") return subject.percentage < 75
                return true
              })
              .map((subject) => (
                <div key={subject.code} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-foreground">{subject.name}</p>
                      <p className="text-xs text-muted-foreground">{subject.code}</p>
                    </div>
                    <div className="text-right">
                      <p className={`text-sm font-bold ${getPercentageColor(subject.percentage)}`}>
                        {subject.percentage.toFixed(1)}%
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {subject.attended}/{subject.total} classes
                      </p>
                    </div>
                  </div>
                  <Progress
                    value={subject.percentage}
                    className={`h-2 ${
                      subject.percentage >= 85
                        ? "[&>div]:bg-success"
                        : subject.percentage >= 75
                        ? "[&>div]:bg-warning"
                        : "[&>div]:bg-destructive"
                    }`}
                  />
                </div>
              ))}
          </CardContent>
        </Card>
      </div>

      {/* Monthly Trend */}
      <Card className="border-border bg-card">
        <CardHeader>
          <CardTitle className="text-lg">Monthly Attendance Trend</CardTitle>
          <CardDescription>Your attendance pattern over the months</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-end justify-between gap-2">
            {attendanceData.monthlyData.map((data) => {
              const percentage = (data.attended / data.total) * 100
              return (
                <div key={data.month} className="flex flex-1 flex-col items-center gap-2">
                  <div className="relative h-32 w-full">
                    <div
                      className={`absolute bottom-0 w-full rounded-t-md ${
                        percentage >= 85
                          ? "bg-success/70"
                          : percentage >= 75
                          ? "bg-warning/70"
                          : "bg-destructive/70"
                      }`}
                      style={{ height: `${percentage}%` }}
                    />
                  </div>
                  <div className="text-center">
                    <p className="text-xs font-medium text-foreground">{percentage.toFixed(0)}%</p>
                    <p className="text-xs text-muted-foreground">{data.month.slice(0, 3)}</p>
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
