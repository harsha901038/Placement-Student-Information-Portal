"use client"

import { useState } from "react"
import { DashboardHeader } from "@/components/dashboard/header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { students, defaultResume } from "@/lib/data"
import {
  Sparkles,
  Upload,
  FileText,
  CheckCircle,
  AlertTriangle,
  XCircle,
  TrendingUp,
  Lightbulb,
  Code,
  Briefcase,
  Award,
  Target,
  RefreshCw,
} from "lucide-react"
import Link from "next/link"

const student = students[0]

// Mock AI analysis results
const analysisResults = {
  overallScore: 78,
  sections: [
    { name: "Contact Info", score: 100, status: "excellent" as const, feedback: "All required contact information is present." },
    { name: "Education", score: 90, status: "good" as const, feedback: "Good education details. Consider adding relevant coursework." },
    { name: "Experience", score: 75, status: "good" as const, feedback: "Good experience section. Add more quantifiable achievements." },
    { name: "Skills", score: 85, status: "good" as const, feedback: "Good variety of skills. Consider organizing by category." },
    { name: "Projects", score: 70, status: "needs-work" as const, feedback: "Add more project details and link to live demos if available." },
    { name: "Formatting", score: 60, status: "needs-work" as const, feedback: "Consider using a cleaner layout with better spacing." },
  ],
  missingSkills: ["TypeScript", "Docker", "Kubernetes", "CI/CD", "GraphQL", "Testing (Jest/Cypress)"],
  improvementTips: [
    "Add quantifiable achievements (e.g., 'Improved performance by 30%')",
    "Include relevant keywords for ATS optimization",
    "Add a professional summary at the top",
    "Include links to your portfolio/GitHub projects",
    "Tailor your resume to each job application",
    "Use action verbs to describe your experience",
  ],
  strengthAreas: [
    "Strong technical skills in JavaScript and React",
    "Good academic performance (8.5 CGPA)",
    "Relevant internship experience",
    "Active certifications",
  ],
}

const scoreColors = {
  excellent: { bg: "bg-accent/20", text: "text-accent", icon: CheckCircle },
  good: { bg: "bg-primary/20", text: "text-primary", icon: TrendingUp },
  "needs-work": { bg: "bg-warning/20", text: "text-warning", icon: AlertTriangle },
  poor: { bg: "bg-destructive/20", text: "text-destructive", icon: XCircle },
}

export default function ResumeAnalyzerPage() {
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [showResults, setShowResults] = useState(true) // Start with results for demo

  const handleAnalyze = () => {
    setIsAnalyzing(true)
    // Simulate AI analysis
    setTimeout(() => {
      setIsAnalyzing(false)
      setShowResults(true)
    }, 2000)
  }

  const getScoreColor = (score: number) => {
    if (score >= 90) return "accent"
    if (score >= 70) return "primary"
    if (score >= 50) return "warning"
    return "destructive"
  }

  return (
    <div className="flex flex-col">
      <DashboardHeader
        title="AI Resume Analyzer"
        description="Get AI-powered insights to improve your resume"
      />

      <div className="flex-1 space-y-6 p-6">
        {/* Upload / Analyze Section */}
        <Card className="border-border bg-card">
          <CardContent className="p-6">
            <div className="flex flex-col items-center justify-between gap-6 sm:flex-row">
              <div className="flex items-center gap-4">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/20 text-primary">
                  <Sparkles className="h-8 w-8" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-foreground">AI Resume Analysis</h2>
                  <p className="text-muted-foreground">
                    Get personalized feedback and suggestions to improve your resume
                  </p>
                </div>
              </div>
              <div className="flex gap-3">
                <Link href="/dashboard/resume">
                  <Button variant="outline">
                    <FileText className="mr-2 h-4 w-4" />
                    Edit Resume
                  </Button>
                </Link>
                <Button onClick={handleAnalyze} disabled={isAnalyzing}>
                  {isAnalyzing ? (
                    <>
                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Sparkles className="mr-2 h-4 w-4" />
                      Analyze Resume
                    </>
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {showResults && (
          <>
            {/* Score Overview */}
            <div className="grid gap-6 lg:grid-cols-3">
              {/* Overall Score */}
              <Card className="border-border bg-card">
                <CardContent className="flex flex-col items-center p-6">
                  <div className="relative">
                    <svg className="h-40 w-40 -rotate-90 transform">
                      <circle
                        cx="80"
                        cy="80"
                        r="70"
                        stroke="var(--color-muted)"
                        strokeWidth="12"
                        fill="none"
                      />
                      <circle
                        cx="80"
                        cy="80"
                        r="70"
                        stroke={`var(--color-${getScoreColor(analysisResults.overallScore)})`}
                        strokeWidth="12"
                        fill="none"
                        strokeDasharray={`${(analysisResults.overallScore / 100) * 440} 440`}
                        strokeLinecap="round"
                      />
                    </svg>
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <span className="text-4xl font-bold text-foreground">{analysisResults.overallScore}</span>
                      <span className="text-sm text-muted-foreground">out of 100</span>
                    </div>
                  </div>
                  <Badge
                    className={`mt-4 ${
                      analysisResults.overallScore >= 80
                        ? "bg-accent text-accent-foreground"
                        : analysisResults.overallScore >= 60
                        ? "bg-primary/20 text-primary"
                        : "bg-warning/20 text-warning"
                    }`}
                  >
                    {analysisResults.overallScore >= 80
                      ? "Excellent Resume"
                      : analysisResults.overallScore >= 60
                      ? "Good Resume"
                      : "Needs Improvement"}
                  </Badge>
                </CardContent>
              </Card>

              {/* Section Scores */}
              <Card className="border-border bg-card lg:col-span-2">
                <CardHeader>
                  <CardTitle>Section Analysis</CardTitle>
                  <CardDescription>Detailed scores for each resume section</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 sm:grid-cols-2">
                    {analysisResults.sections.map((section) => {
                      const { bg, text, icon: Icon } = scoreColors[section.status]
                      return (
                        <div key={section.name} className="rounded-lg border border-border bg-secondary/30 p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <div className={`flex h-8 w-8 items-center justify-center rounded-full ${bg} ${text}`}>
                                <Icon className="h-4 w-4" />
                              </div>
                              <span className="font-medium text-foreground">{section.name}</span>
                            </div>
                            <span className={`text-lg font-bold ${text}`}>{section.score}%</span>
                          </div>
                          <Progress value={section.score} className="mt-3 h-2" />
                          <p className="mt-2 text-xs text-muted-foreground">{section.feedback}</p>
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Detailed Insights */}
            <div className="grid gap-6 lg:grid-cols-2">
              {/* Missing Skills */}
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Code className="h-5 w-5 text-primary" />
                    Missing Skills Suggestions
                  </CardTitle>
                  <CardDescription>
                    Skills frequently requested by employers that you might want to add
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {analysisResults.missingSkills.map((skill) => (
                      <Badge key={skill} variant="outline" className="border-primary/50 text-primary">
                        + {skill}
                      </Badge>
                    ))}
                  </div>
                  <p className="mt-4 text-sm text-muted-foreground">
                    Consider learning these skills to increase your chances of getting shortlisted.
                  </p>
                </CardContent>
              </Card>

              {/* Strength Areas */}
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Award className="h-5 w-5 text-accent" />
                    Your Strengths
                  </CardTitle>
                  <CardDescription>Areas where your resume performs well</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {analysisResults.strengthAreas.map((strength, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <CheckCircle className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
                        <span className="text-sm text-foreground">{strength}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              {/* Improvement Tips */}
              <Card className="border-border bg-card lg:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Lightbulb className="h-5 w-5 text-warning" />
                    AI Improvement Tips
                  </CardTitle>
                  <CardDescription>
                    Actionable suggestions to make your resume stand out
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 sm:grid-cols-2">
                    {analysisResults.improvementTips.map((tip, index) => (
                      <div
                        key={index}
                        className="flex items-start gap-3 rounded-lg border border-border bg-secondary/30 p-4"
                      >
                        <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/20 text-xs font-bold text-primary">
                          {index + 1}
                        </div>
                        <p className="text-sm text-foreground">{tip}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Action Buttons */}
            <Card className="border-border bg-card">
              <CardContent className="flex flex-col items-center justify-between gap-4 p-6 sm:flex-row">
                <div>
                  <h3 className="font-medium text-foreground">Ready to improve your resume?</h3>
                  <p className="text-sm text-muted-foreground">
                    Apply these suggestions to boost your resume score
                  </p>
                </div>
                <div className="flex gap-3">
                  <Link href="/dashboard/resume">
                    <Button>
                      <FileText className="mr-2 h-4 w-4" />
                      Edit Resume
                    </Button>
                  </Link>
                  <Button variant="outline" onClick={handleAnalyze}>
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Re-analyze
                  </Button>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  )
}
