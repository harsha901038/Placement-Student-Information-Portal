"use client"

import { DashboardHeader } from "@/components/dashboard/header"
import { StatsCard } from "@/components/dashboard/stats-card"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { students } from "@/lib/data"
import { GraduationCap, TrendingUp, Calendar, BarChart3 } from "lucide-react"
import { Bar, BarChart, Line, LineChart, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

const student = students[0]

// Prepare SGPA trend data
const sgpaTrendData = student.marks.map((sem) => ({
  semester: `Sem ${sem.semester}`,
  sgpa: sem.sgpa,
}))

export default function AcademicsPage() {
  return (
    <div className="flex flex-col">
      <DashboardHeader title="Academics" description="View your marks, attendance, and CGPA analytics" />

      <div className="flex-1 space-y-6 p-6">
        {/* Stats Grid */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatsCard title="CGPA" value={student.cgpa.toFixed(2)} subtitle="Cumulative GPA" icon={GraduationCap} variant="primary" />
          <StatsCard
            title="Latest SGPA"
            value={student.marks[student.marks.length - 1]?.sgpa.toFixed(2) || "N/A"}
            subtitle={`Semester ${student.marks.length}`}
            icon={TrendingUp}
            variant="accent"
          />
          <StatsCard
            title="Attendance"
            value={`${student.attendance}%`}
            subtitle={student.attendance >= 75 ? "Good Standing" : "Below Minimum"}
            icon={Calendar}
            variant={student.attendance >= 75 ? "accent" : "warning"}
          />
          <StatsCard
            title="Semesters"
            value={student.marks.length}
            subtitle="Completed"
            icon={BarChart3}
            variant="default"
          />
        </div>

        {/* Charts Row */}
        <div className="grid gap-6 lg:grid-cols-2">
          {/* SGPA Trend */}
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle>SGPA Trend</CardTitle>
              <CardDescription>Your semester-wise performance</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  sgpa: { label: "SGPA", color: "var(--color-primary)" },
                }}
                className="h-[300px]"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={sgpaTrendData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                    <XAxis dataKey="semester" stroke="var(--color-muted-foreground)" fontSize={12} />
                    <YAxis domain={[0, 10]} stroke="var(--color-muted-foreground)" fontSize={12} />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Line
                      type="monotone"
                      dataKey="sgpa"
                      stroke="var(--color-primary)"
                      strokeWidth={2}
                      dot={{ fill: "var(--color-primary)", strokeWidth: 2 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>

          {/* Attendance Progress */}
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle>Attendance Overview</CardTitle>
              <CardDescription>Your attendance status</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col items-center justify-center space-y-6">
              <div className="relative flex h-40 w-40 items-center justify-center">
                <svg className="h-full w-full -rotate-90 transform" viewBox="0 0 160 160">
                  <circle cx="80" cy="80" r="64" stroke="var(--color-muted)" strokeWidth="12" fill="none" />
                  <circle
                    cx="80"
                    cy="80"
                    r="64"
                    stroke={student.attendance >= 75 ? "var(--color-accent)" : "var(--color-warning)"}
                    strokeWidth="12"
                    fill="none"
                    strokeDasharray={`${(student.attendance / 100) * 402} 402`}
                    strokeLinecap="round"
                  />
                </svg>
                <div className="absolute flex flex-col items-center">
                  <span className="text-3xl font-bold text-foreground">{student.attendance}%</span>
                  <span className="text-xs text-muted-foreground">Attendance</span>
                </div>
              </div>
              <div className="flex flex-col items-center gap-2">
                <Badge className={student.attendance >= 75 ? "bg-accent text-accent-foreground" : "bg-warning text-warning-foreground"}>
                  {student.attendance >= 75 ? "Good Standing" : "Below Required (75%)"}
                </Badge>
                <p className="text-center text-sm text-muted-foreground">
                  {student.attendance >= 75
                    ? "You are eligible for examinations"
                    : "Improve attendance to be eligible for examinations"}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Semester Marks */}
        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle>Semester-wise Marks</CardTitle>
            <CardDescription>Detailed marks for each semester</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue={`sem-${student.marks.length}`} className="w-full">
              <TabsList className="mb-4 flex flex-wrap gap-2">
                {student.marks.map((sem) => (
                  <TabsTrigger key={sem.semester} value={`sem-${sem.semester}`}>
                    Semester {sem.semester}
                  </TabsTrigger>
                ))}
              </TabsList>
              {student.marks.map((sem) => (
                <TabsContent key={sem.semester} value={`sem-${sem.semester}`}>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between rounded-lg bg-secondary/50 p-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Semester {sem.semester} SGPA</p>
                        <p className="text-2xl font-bold text-foreground">{sem.sgpa.toFixed(2)}</p>
                      </div>
                      <Badge className="bg-primary/20 text-primary">
                        {sem.sgpa >= 9 ? "Excellent" : sem.sgpa >= 8 ? "Very Good" : sem.sgpa >= 7 ? "Good" : "Average"}
                      </Badge>
                    </div>
                    <div className="grid gap-4 sm:grid-cols-2">
                      {sem.subjects.map((subject) => (
                        <div key={subject.name} className="rounded-lg border border-border bg-card p-4">
                          <div className="flex items-center justify-between">
                            <p className="font-medium text-foreground">{subject.name}</p>
                            <Badge variant="outline">
                              {subject.marks}/{subject.maxMarks}
                            </Badge>
                          </div>
                          <div className="mt-3 space-y-1">
                            <Progress value={(subject.marks / subject.maxMarks) * 100} className="h-2" />
                            <p className="text-xs text-muted-foreground">
                              {((subject.marks / subject.maxMarks) * 100).toFixed(0)}% scored
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </TabsContent>
              ))}
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
