"use client"

import { DashboardHeader } from "@/components/dashboard/header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { students, jobs } from "@/lib/data"
import {
  CheckCircle,
  Clock,
  AlertCircle,
  TrendingUp,
  Briefcase,
  Building,
  Calendar,
  MapPin,
  ArrowRight,
  FileText,
} from "lucide-react"
import Link from "next/link"

const student = students[0]

const placementSteps = [
  {
    id: "profile",
    title: "Complete Profile",
    description: "Fill in all your personal and academic details",
    completed: true,
  },
  {
    id: "resume",
    title: "Build Resume",
    description: "Create and upload your professional resume",
    completed: student.resumeCompleted >= 80,
    progress: student.resumeCompleted,
  },
  {
    id: "apply",
    title: "Apply to Jobs",
    description: "Apply to relevant job opportunities",
    completed: student.appliedJobs.length > 0,
  },
  {
    id: "interview",
    title: "Attend Interviews",
    description: "Prepare and attend scheduled interviews",
    completed: student.placementStatus === "shortlisted" || student.placementStatus === "placed",
  },
  {
    id: "placed",
    title: "Get Placed",
    description: "Receive and accept job offer",
    completed: student.placementStatus === "placed",
  },
]

const statusConfig = {
  "not-applied": {
    label: "Not Applied",
    color: "bg-muted text-muted-foreground",
    icon: AlertCircle,
    description: "You haven't applied to any positions yet. Start exploring opportunities!",
  },
  applied: {
    label: "Applied",
    color: "bg-primary/20 text-primary",
    icon: Clock,
    description: "Your applications are being reviewed. Keep checking for updates!",
  },
  shortlisted: {
    label: "Shortlisted",
    color: "bg-warning/20 text-warning",
    icon: TrendingUp,
    description: "Congratulations! You've been shortlisted for interviews.",
  },
  placed: {
    label: "Placed",
    color: "bg-accent/20 text-accent",
    icon: CheckCircle,
    description: `Congratulations! You've been placed at ${student.companyPlaced}!`,
  },
}

const currentStatus = statusConfig[student.placementStatus]
const appliedJobDetails = jobs.filter((job) => student.appliedJobs.includes(job.id))

export default function PlacementPage() {
  return (
    <div className="flex flex-col">
      <DashboardHeader title="Placement Status" description="Track your placement journey and progress" />

      <div className="flex-1 space-y-6 p-6">
        {/* Current Status */}
        <Card className="border-border bg-card">
          <CardContent className="p-6">
            <div className="flex flex-col items-center gap-6 sm:flex-row">
              <div className={`flex h-20 w-20 items-center justify-center rounded-full ${currentStatus.color}`}>
                <currentStatus.icon className="h-10 w-10" />
              </div>
              <div className="flex-1 text-center sm:text-left">
                <h2 className="text-2xl font-bold text-foreground">Status: {currentStatus.label}</h2>
                <p className="mt-2 text-muted-foreground">{currentStatus.description}</p>
              </div>
              {student.placementStatus !== "placed" && (
                <Link href="/dashboard/jobs">
                  <Button>
                    <Briefcase className="mr-2 h-4 w-4" />
                    View Jobs
                  </Button>
                </Link>
              )}
            </div>
          </CardContent>
        </Card>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Journey Progress */}
          <Card className="border-border bg-card lg:col-span-2">
            <CardHeader>
              <CardTitle>Your Placement Journey</CardTitle>
              <CardDescription>Follow these steps to get placed</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {placementSteps.map((step, index) => (
                  <div key={step.id} className="flex gap-4">
                    <div className="flex flex-col items-center">
                      <div
                        className={`flex h-10 w-10 items-center justify-center rounded-full ${
                          step.completed
                            ? "bg-accent text-accent-foreground"
                            : "bg-muted text-muted-foreground"
                        }`}
                      >
                        {step.completed ? <CheckCircle className="h-5 w-5" /> : index + 1}
                      </div>
                      {index < placementSteps.length - 1 && (
                        <div className={`mt-2 h-12 w-0.5 ${step.completed ? "bg-accent" : "bg-muted"}`} />
                      )}
                    </div>
                    <div className="flex-1 pb-6">
                      <div className="flex items-center justify-between">
                        <h3 className="font-medium text-foreground">{step.title}</h3>
                        <Badge variant={step.completed ? "default" : "outline"} className={step.completed ? "bg-accent text-accent-foreground" : ""}>
                          {step.completed ? "Completed" : "Pending"}
                        </Badge>
                      </div>
                      <p className="mt-1 text-sm text-muted-foreground">{step.description}</p>
                      {step.progress !== undefined && !step.completed && (
                        <div className="mt-3 space-y-1">
                          <div className="flex justify-between text-xs">
                            <span className="text-muted-foreground">Progress</span>
                            <span className="text-foreground">{step.progress}%</span>
                          </div>
                          <Progress value={step.progress} className="h-2" />
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <div className="space-y-6">
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle>Quick Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Jobs Applied</span>
                  <span className="font-bold text-foreground">{student.appliedJobs.length}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Resume Score</span>
                  <span className="font-bold text-foreground">{student.resumeScore || 0}/100</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">CGPA</span>
                  <span className="font-bold text-foreground">{student.cgpa}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Certificates</span>
                  <span className="font-bold text-foreground">{student.certificates.length}</span>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle>Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Link href="/dashboard/resume">
                  <Button variant="outline" className="w-full justify-start">
                    <FileText className="mr-2 h-4 w-4" />
                    Improve Resume
                  </Button>
                </Link>
                <Link href="/dashboard/jobs">
                  <Button variant="outline" className="w-full justify-start">
                    <Briefcase className="mr-2 h-4 w-4" />
                    Browse Jobs
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Applied Jobs */}
        {appliedJobDetails.length > 0 && (
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle>Applied Positions</CardTitle>
              <CardDescription>Track the status of your applications</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {appliedJobDetails.map((job) => (
                  <div
                    key={job.id}
                    className="flex flex-col justify-between gap-4 rounded-lg border border-border bg-secondary/30 p-4 sm:flex-row sm:items-center"
                  >
                    <div className="flex items-center gap-4">
                      <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/20 text-primary">
                        <Building className="h-6 w-6" />
                      </div>
                      <div>
                        <h3 className="font-medium text-foreground">{job.title}</h3>
                        <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
                          <span>{job.company}</span>
                          <span>•</span>
                          <span className="flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {job.location}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge variant="secondary" className="capitalize">
                        {job.type}
                      </Badge>
                      <Badge className="bg-primary/20 text-primary">
                        <Clock className="mr-1 h-3 w-3" />
                        Under Review
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
