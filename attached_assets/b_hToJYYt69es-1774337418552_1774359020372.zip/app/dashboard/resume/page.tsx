"use client"

import { useState } from "react"
import { DashboardHeader } from "@/components/dashboard/header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { defaultResume } from "@/lib/data"
import type { Resume } from "@/lib/types"
import {
  User,
  Mail,
  Phone,
  MapPin,
  Linkedin,
  Github,
  Globe,
  GraduationCap,
  Briefcase,
  Code,
  Award,
  Trophy,
  Plus,
  Trash2,
  Download,
  Eye,
  Save,
  Sparkles,
} from "lucide-react"

export default function ResumeBuilderPage() {
  const [resume, setResume] = useState<Resume>(defaultResume)
  const [activeTemplate, setActiveTemplate] = useState<"modern" | "classic" | "minimal">("modern")
  const [newSkill, setNewSkill] = useState("")

  const updatePersonalInfo = (field: keyof Resume["personalInfo"], value: string) => {
    setResume({
      ...resume,
      personalInfo: { ...resume.personalInfo, [field]: value },
    })
  }

  const addSkill = () => {
    if (newSkill.trim() && !resume.skills.includes(newSkill.trim())) {
      setResume({ ...resume, skills: [...resume.skills, newSkill.trim()] })
      setNewSkill("")
    }
  }

  const removeSkill = (skill: string) => {
    setResume({ ...resume, skills: resume.skills.filter((s) => s !== skill) })
  }

  const addEducation = () => {
    setResume({
      ...resume,
      education: [...resume.education, { degree: "", institution: "", year: "", grade: "" }],
    })
  }

  const updateEducation = (index: number, field: string, value: string) => {
    const updated = [...resume.education]
    updated[index] = { ...updated[index], [field]: value }
    setResume({ ...resume, education: updated })
  }

  const removeEducation = (index: number) => {
    setResume({ ...resume, education: resume.education.filter((_, i) => i !== index) })
  }

  const addExperience = () => {
    setResume({
      ...resume,
      experience: [...resume.experience, { title: "", company: "", duration: "", description: "" }],
    })
  }

  const updateExperience = (index: number, field: string, value: string) => {
    const updated = [...resume.experience]
    updated[index] = { ...updated[index], [field]: value }
    setResume({ ...resume, experience: updated })
  }

  const removeExperience = (index: number) => {
    setResume({ ...resume, experience: resume.experience.filter((_, i) => i !== index) })
  }

  const addProject = () => {
    setResume({
      ...resume,
      projects: [...resume.projects, { name: "", description: "", technologies: [], link: "" }],
    })
  }

  const updateProject = (index: number, field: string, value: string | string[]) => {
    const updated = [...resume.projects]
    updated[index] = { ...updated[index], [field]: value }
    setResume({ ...resume, projects: updated })
  }

  const removeProject = (index: number) => {
    setResume({ ...resume, projects: resume.projects.filter((_, i) => i !== index) })
  }

  return (
    <div className="flex flex-col">
      <DashboardHeader
        title="AI Resume Builder"
        description="Create a professional resume with AI assistance"
      />

      <div className="flex-1 p-6">
        <div className="grid gap-6 xl:grid-cols-2">
          {/* Form Section */}
          <div className="space-y-6">
            <Card className="border-border bg-card">
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Sparkles className="h-5 w-5 text-primary" />
                    Resume Editor
                  </CardTitle>
                  <CardDescription>Fill in your details to build your resume</CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <Save className="mr-2 h-4 w-4" />
                    Save Draft
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="personal" className="w-full">
                  <TabsList className="mb-4 grid w-full grid-cols-5">
                    <TabsTrigger value="personal">Personal</TabsTrigger>
                    <TabsTrigger value="education">Education</TabsTrigger>
                    <TabsTrigger value="experience">Experience</TabsTrigger>
                    <TabsTrigger value="projects">Projects</TabsTrigger>
                    <TabsTrigger value="skills">Skills</TabsTrigger>
                  </TabsList>

                  {/* Personal Info Tab */}
                  <TabsContent value="personal" className="space-y-4">
                    <div className="grid gap-4 sm:grid-cols-2">
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-foreground">Full Name</label>
                        <Input
                          value={resume.personalInfo.name}
                          onChange={(e) => updatePersonalInfo("name", e.target.value)}
                          placeholder="John Smith"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-foreground">Email</label>
                        <Input
                          type="email"
                          value={resume.personalInfo.email}
                          onChange={(e) => updatePersonalInfo("email", e.target.value)}
                          placeholder="john@example.com"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-foreground">Phone</label>
                        <Input
                          value={resume.personalInfo.phone}
                          onChange={(e) => updatePersonalInfo("phone", e.target.value)}
                          placeholder="+1 234 567 8900"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-foreground">Address</label>
                        <Input
                          value={resume.personalInfo.address}
                          onChange={(e) => updatePersonalInfo("address", e.target.value)}
                          placeholder="City, State"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-foreground">LinkedIn</label>
                        <Input
                          value={resume.personalInfo.linkedin || ""}
                          onChange={(e) => updatePersonalInfo("linkedin", e.target.value)}
                          placeholder="linkedin.com/in/username"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-foreground">GitHub</label>
                        <Input
                          value={resume.personalInfo.github || ""}
                          onChange={(e) => updatePersonalInfo("github", e.target.value)}
                          placeholder="github.com/username"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-foreground">Career Objective</label>
                      <Textarea
                        value={resume.objective}
                        onChange={(e) => setResume({ ...resume, objective: e.target.value })}
                        placeholder="Write a brief career objective..."
                        rows={4}
                      />
                    </div>
                  </TabsContent>

                  {/* Education Tab */}
                  <TabsContent value="education" className="space-y-4">
                    {resume.education.map((edu, index) => (
                      <Card key={index} className="border-border bg-secondary/30">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between">
                            <h4 className="font-medium text-foreground">Education {index + 1}</h4>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-destructive"
                              onClick={() => removeEducation(index)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                          <div className="mt-4 grid gap-4 sm:grid-cols-2">
                            <div className="space-y-2">
                              <label className="text-sm text-muted-foreground">Degree</label>
                              <Input
                                value={edu.degree}
                                onChange={(e) => updateEducation(index, "degree", e.target.value)}
                                placeholder="B.Tech in Computer Science"
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-sm text-muted-foreground">Institution</label>
                              <Input
                                value={edu.institution}
                                onChange={(e) => updateEducation(index, "institution", e.target.value)}
                                placeholder="University Name"
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-sm text-muted-foreground">Year</label>
                              <Input
                                value={edu.year}
                                onChange={(e) => updateEducation(index, "year", e.target.value)}
                                placeholder="2021 - 2025"
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-sm text-muted-foreground">Grade/CGPA</label>
                              <Input
                                value={edu.grade}
                                onChange={(e) => updateEducation(index, "grade", e.target.value)}
                                placeholder="8.5 CGPA"
                              />
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                    <Button variant="outline" onClick={addEducation} className="w-full">
                      <Plus className="mr-2 h-4 w-4" />
                      Add Education
                    </Button>
                  </TabsContent>

                  {/* Experience Tab */}
                  <TabsContent value="experience" className="space-y-4">
                    {resume.experience.map((exp, index) => (
                      <Card key={index} className="border-border bg-secondary/30">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between">
                            <h4 className="font-medium text-foreground">Experience {index + 1}</h4>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-destructive"
                              onClick={() => removeExperience(index)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                          <div className="mt-4 grid gap-4 sm:grid-cols-2">
                            <div className="space-y-2">
                              <label className="text-sm text-muted-foreground">Job Title</label>
                              <Input
                                value={exp.title}
                                onChange={(e) => updateExperience(index, "title", e.target.value)}
                                placeholder="Software Engineer Intern"
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-sm text-muted-foreground">Company</label>
                              <Input
                                value={exp.company}
                                onChange={(e) => updateExperience(index, "company", e.target.value)}
                                placeholder="TechCorp Inc."
                              />
                            </div>
                            <div className="col-span-2 space-y-2">
                              <label className="text-sm text-muted-foreground">Duration</label>
                              <Input
                                value={exp.duration}
                                onChange={(e) => updateExperience(index, "duration", e.target.value)}
                                placeholder="May 2023 - Aug 2023"
                              />
                            </div>
                            <div className="col-span-2 space-y-2">
                              <label className="text-sm text-muted-foreground">Description</label>
                              <Textarea
                                value={exp.description}
                                onChange={(e) => updateExperience(index, "description", e.target.value)}
                                placeholder="Describe your responsibilities and achievements..."
                                rows={3}
                              />
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                    <Button variant="outline" onClick={addExperience} className="w-full">
                      <Plus className="mr-2 h-4 w-4" />
                      Add Experience
                    </Button>
                  </TabsContent>

                  {/* Projects Tab */}
                  <TabsContent value="projects" className="space-y-4">
                    {resume.projects.map((project, index) => (
                      <Card key={index} className="border-border bg-secondary/30">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between">
                            <h4 className="font-medium text-foreground">Project {index + 1}</h4>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-destructive"
                              onClick={() => removeProject(index)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                          <div className="mt-4 space-y-4">
                            <div className="grid gap-4 sm:grid-cols-2">
                              <div className="space-y-2">
                                <label className="text-sm text-muted-foreground">Project Name</label>
                                <Input
                                  value={project.name}
                                  onChange={(e) => updateProject(index, "name", e.target.value)}
                                  placeholder="E-Commerce Platform"
                                />
                              </div>
                              <div className="space-y-2">
                                <label className="text-sm text-muted-foreground">Link (Optional)</label>
                                <Input
                                  value={project.link || ""}
                                  onChange={(e) => updateProject(index, "link", e.target.value)}
                                  placeholder="github.com/username/project"
                                />
                              </div>
                            </div>
                            <div className="space-y-2">
                              <label className="text-sm text-muted-foreground">Description</label>
                              <Textarea
                                value={project.description}
                                onChange={(e) => updateProject(index, "description", e.target.value)}
                                placeholder="Describe your project..."
                                rows={2}
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-sm text-muted-foreground">Technologies</label>
                              <Input
                                value={project.technologies.join(", ")}
                                onChange={(e) =>
                                  updateProject(
                                    index,
                                    "technologies",
                                    e.target.value.split(",").map((t) => t.trim())
                                  )
                                }
                                placeholder="React, Node.js, MongoDB"
                              />
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                    <Button variant="outline" onClick={addProject} className="w-full">
                      <Plus className="mr-2 h-4 w-4" />
                      Add Project
                    </Button>
                  </TabsContent>

                  {/* Skills Tab */}
                  <TabsContent value="skills" className="space-y-4">
                    <div className="space-y-4">
                      <div className="flex gap-2">
                        <Input
                          value={newSkill}
                          onChange={(e) => setNewSkill(e.target.value)}
                          onKeyDown={(e) => e.key === "Enter" && addSkill()}
                          placeholder="Add a skill..."
                        />
                        <Button onClick={addSkill}>
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {resume.skills.map((skill) => (
                          <Badge key={skill} variant="secondary" className="px-3 py-1">
                            {skill}
                            <button
                              onClick={() => removeSkill(skill)}
                              className="ml-2 hover:text-destructive"
                            >
                              <Trash2 className="h-3 w-3" />
                            </button>
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h4 className="font-medium text-foreground">Certifications</h4>
                      <div className="flex flex-wrap gap-2">
                        {resume.certifications.map((cert, index) => (
                          <Badge key={index} variant="outline" className="px-3 py-1">
                            <Award className="mr-1 h-3 w-3" />
                            {cert}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h4 className="font-medium text-foreground">Achievements</h4>
                      <div className="flex flex-wrap gap-2">
                        {resume.achievements.map((achievement, index) => (
                          <Badge key={index} variant="outline" className="px-3 py-1">
                            <Trophy className="mr-1 h-3 w-3" />
                            {achievement}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          {/* Preview Section */}
          <div className="space-y-6">
            <Card className="border-border bg-card">
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Live Preview</CardTitle>
                  <CardDescription>See how your resume looks</CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <Eye className="mr-2 h-4 w-4" />
                    Preview
                  </Button>
                  <Button size="sm">
                    <Download className="mr-2 h-4 w-4" />
                    Download PDF
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {/* Template Selector */}
                <div className="mb-4 flex gap-2">
                  {(["modern", "classic", "minimal"] as const).map((template) => (
                    <Button
                      key={template}
                      variant={activeTemplate === template ? "default" : "outline"}
                      size="sm"
                      onClick={() => setActiveTemplate(template)}
                      className="capitalize"
                    >
                      {template}
                    </Button>
                  ))}
                </div>

                {/* Resume Preview */}
                <div className="max-h-[700px] overflow-y-auto rounded-lg border border-border bg-white p-6 text-gray-900">
                  {/* Header */}
                  <div className={`border-b pb-4 ${activeTemplate === "modern" ? "border-blue-500" : "border-gray-300"}`}>
                    <h1 className={`text-2xl font-bold ${activeTemplate === "modern" ? "text-blue-600" : "text-gray-900"}`}>
                      {resume.personalInfo.name}
                    </h1>
                    <div className="mt-2 flex flex-wrap gap-4 text-sm text-gray-600">
                      <span className="flex items-center gap-1">
                        <Mail className="h-3 w-3" />
                        {resume.personalInfo.email}
                      </span>
                      <span className="flex items-center gap-1">
                        <Phone className="h-3 w-3" />
                        {resume.personalInfo.phone}
                      </span>
                      {resume.personalInfo.linkedin && (
                        <span className="flex items-center gap-1">
                          <Linkedin className="h-3 w-3" />
                          {resume.personalInfo.linkedin}
                        </span>
                      )}
                      {resume.personalInfo.github && (
                        <span className="flex items-center gap-1">
                          <Github className="h-3 w-3" />
                          {resume.personalInfo.github}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Objective */}
                  {resume.objective && (
                    <div className="mt-4">
                      <h2 className={`font-semibold ${activeTemplate === "modern" ? "text-blue-600" : "text-gray-900"}`}>
                        Career Objective
                      </h2>
                      <p className="mt-1 text-sm text-gray-700">{resume.objective}</p>
                    </div>
                  )}

                  {/* Education */}
                  {resume.education.length > 0 && (
                    <div className="mt-4">
                      <h2 className={`font-semibold ${activeTemplate === "modern" ? "text-blue-600" : "text-gray-900"}`}>
                        Education
                      </h2>
                      <div className="mt-2 space-y-2">
                        {resume.education.map((edu, index) => (
                          <div key={index}>
                            <p className="font-medium text-gray-800">{edu.degree}</p>
                            <p className="text-sm text-gray-600">
                              {edu.institution} | {edu.year} | {edu.grade}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Experience */}
                  {resume.experience.length > 0 && (
                    <div className="mt-4">
                      <h2 className={`font-semibold ${activeTemplate === "modern" ? "text-blue-600" : "text-gray-900"}`}>
                        Experience
                      </h2>
                      <div className="mt-2 space-y-3">
                        {resume.experience.map((exp, index) => (
                          <div key={index}>
                            <p className="font-medium text-gray-800">{exp.title}</p>
                            <p className="text-sm text-gray-600">
                              {exp.company} | {exp.duration}
                            </p>
                            <p className="mt-1 text-sm text-gray-700">{exp.description}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Projects */}
                  {resume.projects.length > 0 && (
                    <div className="mt-4">
                      <h2 className={`font-semibold ${activeTemplate === "modern" ? "text-blue-600" : "text-gray-900"}`}>
                        Projects
                      </h2>
                      <div className="mt-2 space-y-3">
                        {resume.projects.map((project, index) => (
                          <div key={index}>
                            <p className="font-medium text-gray-800">{project.name}</p>
                            <p className="mt-1 text-sm text-gray-700">{project.description}</p>
                            <p className="mt-1 text-xs text-gray-500">
                              Technologies: {project.technologies.join(", ")}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Skills */}
                  {resume.skills.length > 0 && (
                    <div className="mt-4">
                      <h2 className={`font-semibold ${activeTemplate === "modern" ? "text-blue-600" : "text-gray-900"}`}>
                        Skills
                      </h2>
                      <div className="mt-2 flex flex-wrap gap-1">
                        {resume.skills.map((skill) => (
                          <span
                            key={skill}
                            className={`rounded px-2 py-0.5 text-xs ${
                              activeTemplate === "modern"
                                ? "bg-blue-100 text-blue-700"
                                : "bg-gray-100 text-gray-700"
                            }`}
                          >
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
