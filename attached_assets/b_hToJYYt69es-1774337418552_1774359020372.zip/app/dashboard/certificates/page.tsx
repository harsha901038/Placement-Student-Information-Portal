"use client"

import { useState } from "react"
import { DashboardHeader } from "@/components/dashboard/header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { students } from "@/lib/data"
import type { Certificate } from "@/lib/types"
import { Award, Upload, CheckCircle, Clock, Calendar, Building, FileText, Plus, X, Eye } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"

const student = students[0]

export default function CertificatesPage() {
  const [certificates, setCertificates] = useState<Certificate[]>(student.certificates)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [newCertificate, setNewCertificate] = useState({
    name: "",
    issuer: "",
    date: "",
  })

  const handleUpload = () => {
    if (newCertificate.name && newCertificate.issuer && newCertificate.date) {
      const cert: Certificate = {
        id: `c${Date.now()}`,
        name: newCertificate.name,
        issuer: newCertificate.issuer,
        date: newCertificate.date,
        verified: false,
      }
      setCertificates([...certificates, cert])
      setNewCertificate({ name: "", issuer: "", date: "" })
      setIsDialogOpen(false)
    }
  }

  const verifiedCount = certificates.filter((c) => c.verified).length
  const pendingCount = certificates.filter((c) => !c.verified).length

  return (
    <div className="flex flex-col">
      <DashboardHeader title="Certificates" description="Manage and upload your certifications" />

      <div className="flex-1 space-y-6 p-6">
        {/* Stats Row */}
        <div className="grid gap-4 sm:grid-cols-3">
          <Card className="border-border bg-card">
            <CardContent className="flex items-center gap-4 p-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/20 text-primary">
                <Award className="h-6 w-6" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{certificates.length}</p>
                <p className="text-sm text-muted-foreground">Total Certificates</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-border bg-card">
            <CardContent className="flex items-center gap-4 p-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-accent/20 text-accent">
                <CheckCircle className="h-6 w-6" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{verifiedCount}</p>
                <p className="text-sm text-muted-foreground">Verified</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-border bg-card">
            <CardContent className="flex items-center gap-4 p-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-warning/20 text-warning">
                <Clock className="h-6 w-6" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{pendingCount}</p>
                <p className="text-sm text-muted-foreground">Pending Verification</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Upload Card */}
        <Card className="border-border bg-card">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Your Certificates</CardTitle>
              <CardDescription>View and manage your uploaded certifications</CardDescription>
            </div>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Upload Certificate
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Upload New Certificate</DialogTitle>
                  <DialogDescription>Add details about your certification</DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Certificate Name</label>
                    <Input
                      placeholder="e.g., AWS Cloud Practitioner"
                      value={newCertificate.name}
                      onChange={(e) => setNewCertificate({ ...newCertificate, name: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Issuing Organization</label>
                    <Input
                      placeholder="e.g., Amazon Web Services"
                      value={newCertificate.issuer}
                      onChange={(e) => setNewCertificate({ ...newCertificate, issuer: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Date Issued</label>
                    <Input
                      type="date"
                      value={newCertificate.date}
                      onChange={(e) => setNewCertificate({ ...newCertificate, date: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Upload File</label>
                    <div className="flex items-center justify-center rounded-lg border-2 border-dashed border-border bg-secondary/30 p-8">
                      <div className="text-center">
                        <Upload className="mx-auto h-8 w-8 text-muted-foreground" />
                        <p className="mt-2 text-sm text-muted-foreground">
                          Drag and drop or click to upload
                        </p>
                        <p className="text-xs text-muted-foreground">PDF, JPG, PNG up to 5MB</p>
                      </div>
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleUpload}>Upload Certificate</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </CardHeader>
          <CardContent>
            {certificates.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <Award className="h-12 w-12 text-muted-foreground" />
                <h3 className="mt-4 text-lg font-medium text-foreground">No certificates yet</h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  Upload your first certificate to get started
                </p>
              </div>
            ) : (
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {certificates.map((cert) => (
                  <Card key={cert.id} className="border-border bg-secondary/30">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/20 text-primary">
                          <FileText className="h-5 w-5" />
                        </div>
                        <Badge className={cert.verified ? "bg-accent text-accent-foreground" : "bg-warning text-warning-foreground"}>
                          {cert.verified ? "Verified" : "Pending"}
                        </Badge>
                      </div>
                      <h3 className="mt-4 font-medium text-foreground">{cert.name}</h3>
                      <div className="mt-2 space-y-1">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Building className="h-3 w-3" />
                          {cert.issuer}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Calendar className="h-3 w-3" />
                          {cert.date}
                        </div>
                      </div>
                      <div className="mt-4 flex gap-2">
                        <Button variant="outline" size="sm" className="flex-1">
                          <Eye className="mr-2 h-3 w-3" />
                          View
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
