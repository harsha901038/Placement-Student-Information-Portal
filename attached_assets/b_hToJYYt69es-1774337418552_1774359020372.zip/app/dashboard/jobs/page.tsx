"use client"

import { useState } from "react"
import { DashboardHeader } from "@/components/dashboard/header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"
import { jobs, students } from "@/lib/data"
import type { Job } from "@/lib/types"
import {
  Search,
  Briefcase,
  MapPin,
  Clock,
  DollarSign,
  Users,
  Calendar,
  Building,
  CheckCircle,
  Filter,
  ArrowUpDown,
} from "lucide-react"

const student = students[0]

export default function JobsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [typeFilter, setTypeFilter] = useState<string>("all")
  const [sortBy, setSortBy] = useState<string>("recent")
  const [appliedJobs, setAppliedJobs] = useState<string[]>(student.appliedJobs)
  const [selectedJob, setSelectedJob] = useState<Job | null>(null)

  const filteredJobs = jobs
    .filter((job) => {
      const matchesSearch =
        job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        job.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
        job.skills.some((skill) => skill.toLowerCase().includes(searchQuery.toLowerCase()))
      const matchesType = typeFilter === "all" || job.type === typeFilter
      return matchesSearch && matchesType
    })
    .sort((a, b) => {
      if (sortBy === "recent") {
        return new Date(b.postedDate).getTime() - new Date(a.postedDate).getTime()
      }
      if (sortBy === "applicants") {
        return b.applicants - a.applicants
      }
      return 0
    })

  const handleApply = (jobId: string) => {
    if (!appliedJobs.includes(jobId)) {
      setAppliedJobs([...appliedJobs, jobId])
    }
  }

  const openPositions = jobs.filter((j) => j.status === "open").length
  const appliedCount = appliedJobs.length
  const internships = jobs.filter((j) => j.type === "internship").length
  const fullTime = jobs.filter((j) => j.type === "full-time").length

  return (
    <div className="flex flex-col">
      <DashboardHeader
        title="Jobs & Internships"
        description="Explore and apply to placement opportunities"
      />

      <div className="flex-1 space-y-6 p-6">
        {/* Stats Row */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Card className="border-border bg-card">
            <CardContent className="flex items-center gap-4 p-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/20 text-primary">
                <Briefcase className="h-5 w-5" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{openPositions}</p>
                <p className="text-xs text-muted-foreground">Open Positions</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-border bg-card">
            <CardContent className="flex items-center gap-4 p-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/20 text-accent">
                <CheckCircle className="h-5 w-5" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{appliedCount}</p>
                <p className="text-xs text-muted-foreground">Applied</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-border bg-card">
            <CardContent className="flex items-center gap-4 p-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-warning/20 text-warning">
                <Clock className="h-5 w-5" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{internships}</p>
                <p className="text-xs text-muted-foreground">Internships</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-border bg-card">
            <CardContent className="flex items-center gap-4 p-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted text-muted-foreground">
                <Building className="h-5 w-5" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{fullTime}</p>
                <p className="text-xs text-muted-foreground">Full-Time Jobs</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="border-border bg-card">
          <CardContent className="p-4">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search jobs, companies, or skills..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <div className="flex gap-2">
                <Select value={typeFilter} onValueChange={setTypeFilter}>
                  <SelectTrigger className="w-[150px]">
                    <Filter className="mr-2 h-4 w-4" />
                    <SelectValue placeholder="Job Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="full-time">Full-Time</SelectItem>
                    <SelectItem value="part-time">Part-Time</SelectItem>
                    <SelectItem value="internship">Internship</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-[150px]">
                    <ArrowUpDown className="mr-2 h-4 w-4" />
                    <SelectValue placeholder="Sort By" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="recent">Most Recent</SelectItem>
                    <SelectItem value="applicants">Most Applicants</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Job Listings */}
        <div className="grid gap-4 lg:grid-cols-2">
          {filteredJobs.map((job) => (
            <Card key={job.id} className="border-border bg-card transition-all hover:border-primary/50">
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4">
                    <div className="flex h-14 w-14 items-center justify-center rounded-lg bg-primary/20 text-primary">
                      <Building className="h-7 w-7" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">{job.title}</h3>
                      <p className="text-sm text-muted-foreground">{job.company}</p>
                    </div>
                  </div>
                  <Badge
                    variant="secondary"
                    className={`capitalize ${
                      job.type === "internship"
                        ? "bg-warning/20 text-warning"
                        : "bg-primary/20 text-primary"
                    }`}
                  >
                    {job.type}
                  </Badge>
                </div>

                <div className="mt-4 flex flex-wrap gap-3 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <MapPin className="h-4 w-4" />
                    {job.location}
                  </span>
                  <span className="flex items-center gap-1">
                    <DollarSign className="h-4 w-4" />
                    {job.salary}
                  </span>
                  <span className="flex items-center gap-1">
                    <Users className="h-4 w-4" />
                    {job.applicants} applicants
                  </span>
                </div>

                <p className="mt-4 line-clamp-2 text-sm text-muted-foreground">{job.description}</p>

                <div className="mt-4 flex flex-wrap gap-2">
                  {job.skills.slice(0, 4).map((skill) => (
                    <Badge key={skill} variant="outline" className="text-xs">
                      {skill}
                    </Badge>
                  ))}
                  {job.skills.length > 4 && (
                    <Badge variant="outline" className="text-xs">
                      +{job.skills.length - 4} more
                    </Badge>
                  )}
                </div>

                <div className="mt-4 flex items-center justify-between border-t border-border pt-4">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Calendar className="h-3 w-3" />
                    <span>Deadline: {job.deadline}</span>
                  </div>
                  <div className="flex gap-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm" onClick={() => setSelectedJob(job)}>
                          View Details
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-2xl">
                        <DialogHeader>
                          <DialogTitle>{job.title}</DialogTitle>
                          <DialogDescription>{job.company} • {job.location}</DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4 py-4">
                          <div className="flex flex-wrap gap-3">
                            <Badge variant="secondary" className="capitalize">
                              {job.type}
                            </Badge>
                            <Badge variant="outline">{job.salary}</Badge>
                            <Badge variant="outline">{job.applicants} applicants</Badge>
                          </div>
                          <div>
                            <h4 className="font-medium text-foreground">Description</h4>
                            <p className="mt-1 text-sm text-muted-foreground">{job.description}</p>
                          </div>
                          <div>
                            <h4 className="font-medium text-foreground">Requirements</h4>
                            <ul className="mt-1 list-inside list-disc space-y-1 text-sm text-muted-foreground">
                              {job.requirements.map((req, index) => (
                                <li key={index}>{req}</li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <h4 className="font-medium text-foreground">Required Skills</h4>
                            <div className="mt-2 flex flex-wrap gap-2">
                              {job.skills.map((skill) => (
                                <Badge key={skill} variant="outline">
                                  {skill}
                                </Badge>
                              ))}
                            </div>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <span>Posted: {job.postedDate}</span>
                            <span>Deadline: {job.deadline}</span>
                          </div>
                        </div>
                        <DialogFooter>
                          {appliedJobs.includes(job.id) ? (
                            <Button disabled className="bg-accent text-accent-foreground">
                              <CheckCircle className="mr-2 h-4 w-4" />
                              Applied
                            </Button>
                          ) : (
                            <Button onClick={() => handleApply(job.id)}>
                              Apply Now
                            </Button>
                          )}
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                    {appliedJobs.includes(job.id) ? (
                      <Button size="sm" disabled className="bg-accent text-accent-foreground">
                        <CheckCircle className="mr-2 h-4 w-4" />
                        Applied
                      </Button>
                    ) : (
                      <Button size="sm" onClick={() => handleApply(job.id)}>
                        Apply
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredJobs.length === 0 && (
          <Card className="border-border bg-card">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Briefcase className="h-12 w-12 text-muted-foreground" />
              <h3 className="mt-4 text-lg font-medium text-foreground">No jobs found</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                Try adjusting your search or filters
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
