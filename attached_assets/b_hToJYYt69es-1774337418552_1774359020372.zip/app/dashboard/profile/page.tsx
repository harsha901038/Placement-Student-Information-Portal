"use client"

import { useState } from "react"
import { DashboardHeader } from "@/components/dashboard/header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { students } from "@/lib/data"
import { User, Mail, Phone, Building, Calendar, GraduationCap, Save, Edit2, X, Plus } from "lucide-react"

const student = students[0]

export default function ProfilePage() {
  const [isEditing, setIsEditing] = useState(false)
  const [formData, setFormData] = useState({
    name: student.name,
    email: student.email,
    phone: student.phone,
    department: student.department,
    semester: student.semester,
    rollNumber: student.rollNumber,
    skills: student.skills,
  })
  const [newSkill, setNewSkill] = useState("")

  const handleSave = () => {
    // Mock save - would be API call in real app
    setIsEditing(false)
  }

  const addSkill = () => {
    if (newSkill.trim() && !formData.skills.includes(newSkill.trim())) {
      setFormData({ ...formData, skills: [...formData.skills, newSkill.trim()] })
      setNewSkill("")
    }
  }

  const removeSkill = (skillToRemove: string) => {
    setFormData({ ...formData, skills: formData.skills.filter((s) => s !== skillToRemove) })
  }

  return (
    <div className="flex flex-col">
      <DashboardHeader title="Profile" description="Manage your personal and academic information" />

      <div className="flex-1 space-y-6 p-6">
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Profile Card */}
          <Card className="border-border bg-card lg:col-span-1">
            <CardContent className="flex flex-col items-center p-6">
              <div className="flex h-24 w-24 items-center justify-center rounded-full bg-primary/20 text-primary">
                <User className="h-12 w-12" />
              </div>
              <h2 className="mt-4 text-xl font-bold text-foreground">{formData.name}</h2>
              <p className="text-sm text-muted-foreground">{formData.rollNumber}</p>
              <Badge className="mt-2 bg-primary/20 text-primary">{formData.department}</Badge>

              <div className="mt-6 w-full space-y-3">
                <div className="flex items-center gap-3 text-sm">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <span className="text-foreground">{formData.email}</span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <span className="text-foreground">{formData.phone}</span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <GraduationCap className="h-4 w-4 text-muted-foreground" />
                  <span className="text-foreground">Semester {formData.semester}</span>
                </div>
              </div>

              <div className="mt-6 grid w-full grid-cols-2 gap-4 border-t border-border pt-6">
                <div className="text-center">
                  <p className="text-2xl font-bold text-primary">{student.cgpa}</p>
                  <p className="text-xs text-muted-foreground">CGPA</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-accent">{student.attendance}%</p>
                  <p className="text-xs text-muted-foreground">Attendance</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Edit Form */}
          <Card className="border-border bg-card lg:col-span-2">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Personal Information</CardTitle>
                <CardDescription>Update your personal and contact details</CardDescription>
              </div>
              {!isEditing ? (
                <Button onClick={() => setIsEditing(true)}>
                  <Edit2 className="mr-2 h-4 w-4" />
                  Edit
                </Button>
              ) : (
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => setIsEditing(false)}>
                    <X className="mr-2 h-4 w-4" />
                    Cancel
                  </Button>
                  <Button onClick={handleSave}>
                    <Save className="mr-2 h-4 w-4" />
                    Save
                  </Button>
                </div>
              )}
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 sm:grid-cols-2">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Full Name</label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    disabled={!isEditing}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Email</label>
                  <Input
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    disabled={!isEditing}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Phone</label>
                  <Input
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    disabled={!isEditing}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Department</label>
                  <Input value={formData.department} disabled />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Roll Number</label>
                  <Input value={formData.rollNumber} disabled />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Semester</label>
                  <Input value={`Semester ${formData.semester}`} disabled />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Skills Section */}
          <Card className="border-border bg-card lg:col-span-3">
            <CardHeader>
              <CardTitle>Skills</CardTitle>
              <CardDescription>Add skills that highlight your expertise</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {formData.skills.map((skill) => (
                  <Badge key={skill} variant="secondary" className="px-3 py-1">
                    {skill}
                    {isEditing && (
                      <button onClick={() => removeSkill(skill)} className="ml-2 hover:text-destructive">
                        <X className="h-3 w-3" />
                      </button>
                    )}
                  </Badge>
                ))}
                {isEditing && (
                  <div className="flex items-center gap-2">
                    <Input
                      placeholder="Add skill"
                      value={newSkill}
                      onChange={(e) => setNewSkill(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && addSkill()}
                      className="w-32"
                    />
                    <Button size="sm" onClick={addSkill}>
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
