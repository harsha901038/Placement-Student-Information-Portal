"use client"

import { DashboardHeader } from "@/components/dashboard/header"
import { StatsCard } from "@/components/dashboard/stats-card"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { students, jobs, announcements } from "@/lib/data"
import {
  GraduationCap,
  BarChart3,
  FileText,
  Briefcase,
  Calendar,
  ArrowRight,
  CheckCircle,
  Clock,
  AlertCircle,
  TrendingUp,
  Award,
} from "lucide-react"
import Link from "next/link"

// Get the logged-in student data (mock - first student)
const student = students[0]

const placementStatusConfig = {
  "not-applied": { label: "Not Applied", color: "bg-muted text-muted-foreground", icon: AlertCircle },
  applied: { label: "Applied", color: "bg-primary/20 text-primary", icon: Clock },
  shortlisted: { label: "Shortlisted", color: "bg-warning/20 text-warning", icon: TrendingUp },
  placed: { label: "Placed", color: "bg-accent/20 text-accent", icon: CheckCircle },
}

export default function StudentDashboard() {
  const statusConfig = placementStatusConfig[student.placementStatus]

  return (
    <div className="flex flex-col">
      <DashboardHeader title="Dashboard" description="Welcome back! Here's your placement overview." />

      <div className="flex-1 space-y-6 p-6">
        {/* Stats Grid */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatsCard
            title="CGPA"
            value={student.cgpa.toFixed(1)}
            subtitle="Current Grade"
            icon={GraduationCap}
            variant="primary"
          />
          <StatsCard
            title="Attendance"
            value={`${student.attendance}%`}
            subtitle="Overall Attendance"
            icon={Calendar}
            variant={student.attendance >= 75 ? "accent" : "warning"}
          />
          <StatsCard
            title="Resume Score"
            value={`${student.resumeScore || 0}/100`}
            subtitle="AI Analysis Score"
            icon={FileText}
            variant="primary"
          />
          <StatsCard
            title="Jobs Applied"
            value={student.appliedJobs.length}
            subtitle={`${jobs.filter((j) => j.status === "open").length} open positions`}
            icon={Briefcase}
            variant="accent"
          />
        </div>

        {/* Main Content Grid */}
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Left Column */}
          <div className="space-y-6 lg:col-span-2">
            {/* Placement Status Card */}
            <Card className="border-border bg-card">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <div>
                  <CardTitle>Placement Status</CardTitle>
                  <CardDescription>Your current placement journey</CardDescription>
                </div>
                <Link href="/dashboard/placement">
                  <Button variant="ghost" size="sm">
                    View Details <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4">
                  <div className={`flex h-14 w-14 items-center justify-center rounded-full ${statusConfig.color}`}>
                    <statusConfig.icon className="h-7 w-7" />
                  </div>
                  <div>
                    <p className="text-lg font-semibold text-foreground">{statusConfig.label}</p>
                    <p className="text-sm text-muted-foreground">
                      {student.placementStatus === "placed"
                        ? `Placed at ${student.companyPlaced}`
                        : student.placementStatus === "shortlisted"
                        ? "You are shortlisted for upcoming interviews"
                        : student.placementStatus === "applied"
                        ? "Your applications are under review"
                        : "Start applying to job opportunities"}
                    </p>
                  </div>
                </div>

                {/* Progress Steps */}
                <div className="mt-6 flex items-center justify-between">
                  {["Not Applied", "Applied", "Shortlisted", "Placed"].map((step, index) => {
                    const stepIndex = ["not-applied", "applied", "shortlisted", "placed"].indexOf(
                      student.placementStatus
                    )
                    const isCompleted = index <= stepIndex
                    const isCurrent = index === stepIndex

                    return (
                      <div key={step} className="flex flex-1 items-center">
                        <div className="flex flex-col items-center">
                          <div
                            className={`flex h-8 w-8 items-center justify-center rounded-full text-sm font-medium ${
                              isCompleted
                                ? "bg-primary text-primary-foreground"
                                : "bg-muted text-muted-foreground"
                            }`}
                          >
                            {isCompleted ? <CheckCircle className="h-4 w-4" /> : index + 1}
                          </div>
                          <span
                            className={`mt-2 text-xs ${
                              isCurrent ? "font-medium text-foreground" : "text-muted-foreground"
                            }`}
                          >
                            {step}
                          </span>
                        </div>
                        {index < 3 && (
                          <div
                            className={`h-0.5 flex-1 ${
                              index < stepIndex ? "bg-primary" : "bg-muted"
                            }`}
                          />
                        )}
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Resume Tracker */}
            <Card className="border-border bg-card">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <div>
                  <CardTitle>Resume Tracker</CardTitle>
                  <CardDescription>Build a stronger resume</CardDescription>
                </div>
                <Link href="/dashboard/resume">
                  <Button variant="ghost" size="sm">
                    Edit Resume <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/20 text-primary">
                        <FileText className="h-5 w-5" />
                      </div>
                      <div>
                        <p className="font-medium text-foreground">Resume Completion</p>
                        <p className="text-sm text-muted-foreground">
                          Last updated: {student.lastResumeUpdate || "Never"}
                        </p>
                      </div>
                    </div>
                    <Badge
                      variant={
                        student.resumeCompleted >= 80
                          ? "default"
                          : student.resumeCompleted >= 50
                          ? "secondary"
                          : "outline"
                      }
                      className={
                        student.resumeCompleted >= 80
                          ? "bg-accent text-accent-foreground"
                          : student.resumeCompleted >= 50
                          ? "bg-warning text-warning-foreground"
                          : ""
                      }
                    >
                      {student.resumeCompleted >= 80
                        ? "Excellent"
                        : student.resumeCompleted >= 50
                        ? "Good"
                        : "Incomplete"}
                    </Badge>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Progress</span>
                      <span className="font-medium text-foreground">{student.resumeCompleted}%</span>
                    </div>
                    <Progress value={student.resumeCompleted} className="h-2" />
                  </div>
                  <div className="grid gap-2 sm:grid-cols-2">
                    <Link href="/dashboard/resume">
                      <Button variant="default" className="w-full">
                        <FileText className="mr-2 h-4 w-4" />
                        Build Resume
                      </Button>
                    </Link>
                    <Link href="/dashboard/analyzer">
                      <Button variant="outline" className="w-full">
                        <BarChart3 className="mr-2 h-4 w-4" />
                        Analyze Resume
                      </Button>
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recent Jobs */}
            <Card className="border-border bg-card">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <div>
                  <CardTitle>Recent Opportunities</CardTitle>
                  <CardDescription>Latest jobs and internships</CardDescription>
                </div>
                <Link href="/dashboard/jobs">
                  <Button variant="ghost" size="sm">
                    View All <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {jobs.slice(0, 3).map((job) => (
                    <div
                      key={job.id}
                      className="flex items-center justify-between rounded-lg border border-border bg-secondary/30 p-4"
                    >
                      <div className="flex items-center gap-4">
                        <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/20 text-primary">
                          <Briefcase className="h-6 w-6" />
                        </div>
                        <div>
                          <p className="font-medium text-foreground">{job.title}</p>
                          <p className="text-sm text-muted-foreground">
                            {job.company} • {job.location}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Badge variant="secondary" className="capitalize">
                          {job.type}
                        </Badge>
                        {student.appliedJobs.includes(job.id) ? (
                          <Badge className="bg-accent text-accent-foreground">Applied</Badge>
                        ) : (
                          <Link href="/dashboard/jobs">
                            <Button size="sm">Apply</Button>
                          </Link>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="grid gap-2">
                <Link href="/dashboard/resume">
                  <Button variant="outline" className="w-full justify-start">
                    <FileText className="mr-2 h-4 w-4" />
                    Edit Resume
                  </Button>
                </Link>
                <Link href="/dashboard/certificates">
                  <Button variant="outline" className="w-full justify-start">
                    <Award className="mr-2 h-4 w-4" />
                    Upload Certificate
                  </Button>
                </Link>
                <Link href="/dashboard/profile">
                  <Button variant="outline" className="w-full justify-start">
                    <GraduationCap className="mr-2 h-4 w-4" />
                    Update Profile
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Skills */}
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle>Your Skills</CardTitle>
                <CardDescription>Skills on your profile</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {student.skills.map((skill) => (
                    <Badge key={skill} variant="secondary">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Announcements */}
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle>Announcements</CardTitle>
                <CardDescription>Latest updates from placement cell</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {announcements.slice(0, 3).map((announcement) => (
                    <div key={announcement.id} className="space-y-1">
                      <div className="flex items-center gap-2">
                        <Badge
                          variant="outline"
                          className={
                            announcement.priority === "high"
                              ? "border-destructive text-destructive"
                              : announcement.priority === "medium"
                              ? "border-warning text-warning"
                              : ""
                          }
                        >
                          {announcement.priority}
                        </Badge>
                        <span className="text-xs text-muted-foreground">{announcement.date}</span>
                      </div>
                      <p className="text-sm font-medium text-foreground">{announcement.title}</p>
                      <p className="text-xs text-muted-foreground line-clamp-2">{announcement.content}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Certificates */}
            <Card className="border-border bg-card">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <div>
                  <CardTitle>Certificates</CardTitle>
                  <CardDescription>{student.certificates.length} uploaded</CardDescription>
                </div>
                <Link href="/dashboard/certificates">
                  <Button variant="ghost" size="sm">
                    View All
                  </Button>
                </Link>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {student.certificates.slice(0, 2).map((cert) => (
                    <div key={cert.id} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Award className={`h-4 w-4 ${cert.verified ? "text-accent" : "text-muted-foreground"}`} />
                        <span className="text-sm text-foreground">{cert.name}</span>
                      </div>
                      <Badge variant={cert.verified ? "default" : "outline"} className={cert.verified ? "bg-accent text-accent-foreground" : ""}>
                        {cert.verified ? "Verified" : "Pending"}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
